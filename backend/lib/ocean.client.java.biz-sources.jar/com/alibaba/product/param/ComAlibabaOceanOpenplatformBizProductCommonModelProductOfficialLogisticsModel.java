package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsModel {

    private ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsInfoModel officialLogisticsInfoModel;

    /**
     * @return 无sku时，官方商品物流模型，长宽高等
     */
    public ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsInfoModel getOfficialLogisticsInfoModel() {
        return officialLogisticsInfoModel;
    }

    /**
     * 设置无sku时，官方商品物流模型，长宽高等     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setOfficialLogisticsInfoModel(ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsInfoModel officialLogisticsInfoModel) {
        this.officialLogisticsInfoModel = officialLogisticsInfoModel;
    }

    private ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsSkuInfoModel[] officialLogisticsSkuInfoModels;

    /**
     * @return 有sku时，官方商品的sku的物流模型，长宽高等
     */
    public ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsSkuInfoModel[] getOfficialLogisticsSkuInfoModels() {
        return officialLogisticsSkuInfoModels;
    }

    /**
     * 设置有sku时，官方商品的sku的物流模型，长宽高等     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setOfficialLogisticsSkuInfoModels(
            ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsSkuInfoModel[] officialLogisticsSkuInfoModels) {
        this.officialLogisticsSkuInfoModels = officialLogisticsSkuInfoModels;
    }

}
