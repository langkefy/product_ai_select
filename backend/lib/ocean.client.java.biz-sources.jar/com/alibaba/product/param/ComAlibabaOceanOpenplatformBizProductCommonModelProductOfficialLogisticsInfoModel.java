package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizProductCommonModelProductOfficialLogisticsInfoModel {

    private Double length;

    /**
     * @return 长
     */
    public Double getLength() {
        return length;
    }

    /**
     * 设置长     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setLength(Double length) {
        this.length = length;
    }

    private Double width;

    /**
     * @return 宽
     */
    public Double getWidth() {
        return width;
    }

    /**
     * 设置宽     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setWidth(Double width) {
        this.width = width;
    }

    private Double height;

    /**
     * @return 高
     */
    public Double getHeight() {
        return height;
    }

    /**
     * 设置高     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setHeight(Double height) {
        this.height = height;
    }

    private Long weight;

    /**
     * @return 重量
     */
    public Long getWeight() {
        return weight;
    }

    /**
     * 设置重量     *
     * 参数示例：<pre>100</pre>     
     * 此参数必填
     */
    public void setWeight(Long weight) {
        this.weight = weight;
    }

    private Double volume;

    /**
     * @return 体积
     */
    public Double getVolume() {
        return volume;
    }

    /**
     * 设置体积     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setVolume(Double volume) {
        this.volume = volume;
    }

}
