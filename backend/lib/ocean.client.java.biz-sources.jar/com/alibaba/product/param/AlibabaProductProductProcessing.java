package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductProductProcessing {

    private String[] images;

    /**
     * @return 定制商品样图
     */
    public String[] getImages() {
        return images;
    }

    /**
     * 设置定制商品样图     *
     * 参数示例：<pre>["https://1.jpg","https://1.jpg"]</pre>     
     * 此参数必填
     */
    public void setImages(String[] images) {
        this.images = images;
    }

    private String[] customType;

    /**
     * @return 定制方式，可选值: processing、sku
     */
    public String[] getCustomType() {
        return customType;
    }

    /**
     * 设置定制方式，可选值: processing、sku     *
     * 参数示例：<pre>["processing"]</pre>     
     * 此参数必填
     */
    public void setCustomType(String[] customType) {
        this.customType = customType;
    }

    private Double minPrice;

    /**
     * @return 价格区间的最低价	
     */
    public Double getMinPrice() {
        return minPrice;
    }

    /**
     * 设置价格区间的最低价	     *
     * 参数示例：<pre>10.00</pre>     
     * 此参数必填
     */
    public void setMinPrice(Double minPrice) {
        this.minPrice = minPrice;
    }

    private Double maxPrice;

    /**
     * @return 价格区间的最高价
     */
    public Double getMaxPrice() {
        return maxPrice;
    }

    /**
     * 设置价格区间的最高价     *
     * 参数示例：<pre>100.00</pre>     
     * 此参数必填
     */
    public void setMaxPrice(Double maxPrice) {
        this.maxPrice = maxPrice;
    }

    private Long minOrderQuantity;

    /**
     * @return 最小起订量
     */
    public Long getMinOrderQuantity() {
        return minOrderQuantity;
    }

    /**
     * 设置最小起订量     *
     * 参数示例：<pre>50</pre>     
     * 此参数必填
     */
    public void setMinOrderQuantity(Long minOrderQuantity) {
        this.minOrderQuantity = minOrderQuantity;
    }

    private long[] stockOfferIds;

    /**
     * @return 关联现货商品的id列表
     */
    public long[] getStockOfferIds() {
        return stockOfferIds;
    }

    /**
     * 设置关联现货商品的id列表     *
     * 参数示例：<pre>[6386,6387]</pre>     
     * 此参数必填
     */
    public void setStockOfferIds(long[] stockOfferIds) {
        this.stockOfferIds = stockOfferIds;
    }

    private AlibabaProductReserveRange[] reserveRanges;

    /**
     * @return 出货周期	
     */
    public AlibabaProductReserveRange[] getReserveRanges() {
        return reserveRanges;
    }

    /**
     * 设置出货周期	     *
     * 参数示例：<pre>[{"quantity":100,"period":10}]</pre>     
     * 此参数必填
     */
    public void setReserveRanges(AlibabaProductReserveRange[] reserveRanges) {
        this.reserveRanges = reserveRanges;
    }

    private AlibabaProductSampleInfo sampleInfo;

    /**
     * @return 打样信息	
     */
    public AlibabaProductSampleInfo getSampleInfo() {
        return sampleInfo;
    }

    /**
     * 设置打样信息	     *
     * 参数示例：<pre>	{"isSupportSample":true,"price":10,"period":2}</pre>     
     * 此参数必填
     */
    public void setSampleInfo(AlibabaProductSampleInfo sampleInfo) {
        this.sampleInfo = sampleInfo;
    }

}
