package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductSampleInfo {

    private Double price;

    /**
     * @return 打样价格（单位：元）
     */
    public Double getPrice() {
        return price;
    }

    /**
     * 设置打样价格（单位：元）     *
     * 参数示例：<pre>10.00</pre>     
     * 此参数必填
     */
    public void setPrice(Double price) {
        this.price = price;
    }

    private Integer period;

    /**
     * @return 打样周期（单位：天）
     */
    public Integer getPeriod() {
        return period;
    }

    /**
     * 设置打样周期（单位：天）     *
     * 参数示例：<pre>2</pre>     
     * 此参数必填
     */
    public void setPeriod(Integer period) {
        this.period = period;
    }

    private Boolean isSupportSample;

    /**
     * @return 是否支持打样
     */
    public Boolean getIsSupportSample() {
        return isSupportSample;
    }

    /**
     * 设置是否支持打样     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setIsSupportSample(Boolean isSupportSample) {
        this.isSupportSample = isSupportSample;
    }

}
