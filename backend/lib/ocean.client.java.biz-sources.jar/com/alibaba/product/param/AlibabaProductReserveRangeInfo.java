package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductReserveRangeInfo {

    private Long quantity;

    /**
     * @return 订货数量
     */
    public Long getQuantity() {
        return quantity;
    }

    /**
     * 设置订货数量     *
     * 参数示例：<pre>1000</pre>     
     * 此参数必填
     */
    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    private Integer period;

    /**
     * @return 出货时间(天)
     */
    public Integer getPeriod() {
        return period;
    }

    /**
     * 设置出货时间(天)     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setPeriod(Integer period) {
        this.period = period;
    }

}
