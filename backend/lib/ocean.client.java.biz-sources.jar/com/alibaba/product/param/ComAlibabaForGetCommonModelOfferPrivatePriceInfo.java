package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaForGetCommonModelOfferPrivatePriceInfo {

    private Long skuId;

    /**
     * @return skuid，非规格报价为0
     */
    public Long getSkuId() {
        return skuId;
    }

    /**
     * 设置skuid，非规格报价为0     *
     * 参数示例：<pre>0</pre>     
     * 此参数必填
     */
    public void setSkuId(Long skuId) {
        this.skuId = skuId;
    }

    private String privatePriceInfo;

    /**
     * @return 具体会员等级价格（普通，高级，vip，至尊vip，初级）注意会员顺序
     */
    public String getPrivatePriceInfo() {
        return privatePriceInfo;
    }

    /**
     * 设置具体会员等级价格（普通，高级，vip，至尊vip，初级）注意会员顺序     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setPrivatePriceInfo(String privatePriceInfo) {
        this.privatePriceInfo = privatePriceInfo;
    }

}
