package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductReserveRange {

    private Long beginAmount;

    /**
     * @return 订货数量
     */
    public Long getBeginAmount() {
        return beginAmount;
    }

    /**
     * 设置订货数量     *
     * 参数示例：<pre>100</pre>     
     * 此参数必填
     */
    public void setBeginAmount(Long beginAmount) {
        this.beginAmount = beginAmount;
    }

    private Integer date;

    /**
     * @return 预计出货时间（天）
     */
    public Integer getDate() {
        return date;
    }

    /**
     * 设置预计出货时间（天）     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setDate(Integer date) {
        this.date = date;
    }

    private Long endAmount;

    /**
     * @return 订货截止数量
     */
    public Long getEndAmount() {
        return endAmount;
    }

    /**
     * 设置订货截止数量     *
     * 参数示例：<pre>100</pre>     
     * 此参数必填
     */
    public void setEndAmount(Long endAmount) {
        this.endAmount = endAmount;
    }

    private Long quantity;

    /**
     * @return 订货起订数量
     */
    public Long getQuantity() {
        return quantity;
    }

    /**
     * 设置订货起订数量     *
     * 参数示例：<pre>1000</pre>     
     * 此参数必填
     */
    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    private Integer period;

    /**
     * @return 预计出货时间（天）
     */
    public Integer getPeriod() {
        return period;
    }

    /**
     * 设置预计出货时间（天）     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setPeriod(Integer period) {
        this.period = period;
    }

}
