package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductReserveInfo {

    private Boolean supportReserve;

    /**
     * @return 是否支持订货
     */
    public Boolean getSupportReserve() {
        return supportReserve;
    }

    /**
     * 设置是否支持订货     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setSupportReserve(Boolean supportReserve) {
        this.supportReserve = supportReserve;
    }

    private Long minQuantity;

    /**
     * @return 最小订货量
     */
    public Long getMinQuantity() {
        return minQuantity;
    }

    /**
     * 设置最小订货量     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setMinQuantity(Long minQuantity) {
        this.minQuantity = minQuantity;
    }

    private Long maxQuantity;

    /**
     * @return 最大订货量
     */
    public Long getMaxQuantity() {
        return maxQuantity;
    }

    /**
     * 设置最大订货量     *
     * 参数示例：<pre>1000</pre>     
     * 此参数必填
     */
    public void setMaxQuantity(Long maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    private AlibabaProductReserveRangeInfo[] reserveRangeInfos;

    /**
     * @return 订货区间信息
     */
    public AlibabaProductReserveRangeInfo[] getReserveRangeInfos() {
        return reserveRangeInfos;
    }

    /**
     * 设置订货区间信息     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setReserveRangeInfos(AlibabaProductReserveRangeInfo[] reserveRangeInfos) {
        this.reserveRangeInfos = reserveRangeInfos;
    }

}
