package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductProductSKUInfo {

    private AlibabaProductSKUAttrInfo[] attributes;

    /**
     * @return SKU属性值，可填多组信息
     */
    public AlibabaProductSKUAttrInfo[] getAttributes() {
        return attributes;
    }

    /**
     * 设置SKU属性值，可填多组信息     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setAttributes(AlibabaProductSKUAttrInfo[] attributes) {
        this.attributes = attributes;
    }

    private String cargoNumber;

    /**
     * @return 指定规格的货号，国际站无需关注
     */
    public String getCargoNumber() {
        return cargoNumber;
    }

    /**
     * 设置指定规格的货号，国际站无需关注     *
     * 参数示例：<pre>cy小黄人</pre>     
     * 此参数必填
     */
    public void setCargoNumber(String cargoNumber) {
        this.cargoNumber = cargoNumber;
    }

    private Integer amountOnSale;

    /**
     * @return 可销售数量，国际站无需关注
     */
    public Integer getAmountOnSale() {
        return amountOnSale;
    }

    /**
     * 设置可销售数量，国际站无需关注     *
     * 参数示例：<pre>1200</pre>     
     * 此参数必填
     */
    public void setAmountOnSale(Integer amountOnSale) {
        this.amountOnSale = amountOnSale;
    }

    private Double retailPrice;

    /**
     * @return 建议零售价，国际站无需关注
     */
    public Double getRetailPrice() {
        return retailPrice;
    }

    /**
     * 设置建议零售价，国际站无需关注     *
     * 参数示例：<pre>40</pre>     
     * 此参数必填
     */
    public void setRetailPrice(Double retailPrice) {
        this.retailPrice = retailPrice;
    }

    private Double price;

    /**
     * @return 报价时该规格的单价，国际站注意要点：含有SKU属性的在线批发产品设定具体价格时使用此值，若设置阶梯价格则使用priceRange
     */
    public Double getPrice() {
        return price;
    }

    /**
     * 设置报价时该规格的单价，国际站注意要点：含有SKU属性的在线批发产品设定具体价格时使用此值，若设置阶梯价格则使用priceRange     *
     * 参数示例：<pre>40</pre>     
     * 此参数必填
     */
    public void setPrice(Double price) {
        this.price = price;
    }

    private AlibabaProductProductPriceRange[] priceRange;

    /**
     * @return 阶梯报价，1688无需关注
     */
    public AlibabaProductProductPriceRange[] getPriceRange() {
        return priceRange;
    }

    /**
     * 设置阶梯报价，1688无需关注     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setPriceRange(AlibabaProductProductPriceRange[] priceRange) {
        this.priceRange = priceRange;
    }

    private String skuCode;

    /**
     * @return 商品编码，1688无需关注
     */
    public String getSkuCode() {
        return skuCode;
    }

    /**
     * 设置商品编码，1688无需关注     *
     * 参数示例：<pre>3746778972330</pre>     
     * 此参数必填
     */
    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    private Long skuId;

    /**
     * @return skuId, 国际站无需关注
     */
    public Long getSkuId() {
        return skuId;
    }

    /**
     * 设置skuId, 国际站无需关注     *
     * 参数示例：<pre>3746778972330</pre>     
     * 此参数必填
     */
    public void setSkuId(Long skuId) {
        this.skuId = skuId;
    }

    private String specId;

    /**
     * @return specId, 国际站无需关注
     */
    public String getSpecId() {
        return specId;
    }

    /**
     * 设置specId, 国际站无需关注     *
     * 参数示例：<pre>fb82997a5b64af3c729cea89bef44409</pre>     
     * 此参数必填
     */
    public void setSpecId(String specId) {
        this.specId = specId;
    }

    private Double consignPrice;

    /**
     * @return 分销基准价
     */
    public Double getConsignPrice() {
        return consignPrice;
    }

    /**
     * 设置分销基准价     *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setConsignPrice(Double consignPrice) {
        this.consignPrice = consignPrice;
    }

    private Double takeSamplePrice;

    /**
     * @return SKU 维度拿样价, 国际站无需关注
     */
    public Double getTakeSamplePrice() {
        return takeSamplePrice;
    }

    /**
     * 设置SKU 维度拿样价, 国际站无需关注     *
     * 参数示例：<pre>1.00</pre>     
     * 此参数必填
     */
    public void setTakeSamplePrice(Double takeSamplePrice) {
        this.takeSamplePrice = takeSamplePrice;
    }

    private Double pftPrice;

    /**
     * @return 批发团价格
     */
    public Double getPftPrice() {
        return pftPrice;
    }

    /**
     * 设置批发团价格     *
     * 参数示例：<pre>0.1</pre>     
     * 此参数必填
     */
    public void setPftPrice(Double pftPrice) {
        this.pftPrice = pftPrice;
    }

    private Double jxhyPrice;

    /**
     * @return 精选货源价
     */
    public Double getJxhyPrice() {
        return jxhyPrice;
    }

    /**
     * 设置精选货源价     *
     * 参数示例：<pre>0.1</pre>     
     * 此参数必填
     */
    public void setJxhyPrice(Double jxhyPrice) {
        this.jxhyPrice = jxhyPrice;
    }

    private Double jxhyPfPrice;

    /**
     * @return 精选货源价批发价
     */
    public Double getJxhyPfPrice() {
        return jxhyPfPrice;
    }

    /**
     * 设置精选货源价批发价     *
     * 参数示例：<pre>5.5</pre>     
     * 此参数必填
     */
    public void setJxhyPfPrice(Double jxhyPfPrice) {
        this.jxhyPfPrice = jxhyPfPrice;
    }

    private Double dailySpecialPrice;

    /**
     * @return 天天特卖价
     */
    public Double getDailySpecialPrice() {
        return dailySpecialPrice;
    }

    /**
     * 设置天天特卖价     *
     * 参数示例：<pre>5.4</pre>     
     * 此参数必填
     */
    public void setDailySpecialPrice(Double dailySpecialPrice) {
        this.dailySpecialPrice = dailySpecialPrice;
    }

    private Double eleXdChannelPrice;

    /**
     * @return 饿了么小店专属价
     */
    public Double getEleXdChannelPrice() {
        return eleXdChannelPrice;
    }

    /**
     * 设置饿了么小店专属价     *
     * 参数示例：<pre>5.4</pre>     
     * 此参数必填
     */
    public void setEleXdChannelPrice(Double eleXdChannelPrice) {
        this.eleXdChannelPrice = eleXdChannelPrice;
    }

}
