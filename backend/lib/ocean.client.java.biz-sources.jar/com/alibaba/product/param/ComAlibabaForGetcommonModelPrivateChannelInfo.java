package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaForGetcommonModelPrivateChannelInfo {

    private ComAlibabaForGetCommonModelOfferPrivatePriceInfo[] offerPrivatePriceInfo;

    /**
     * @return 私密商品私密价格信息
     */
    public ComAlibabaForGetCommonModelOfferPrivatePriceInfo[] getOfferPrivatePriceInfo() {
        return offerPrivatePriceInfo;
    }

    /**
     * 设置私密商品私密价格信息     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setOfferPrivatePriceInfo(ComAlibabaForGetCommonModelOfferPrivatePriceInfo[] offerPrivatePriceInfo) {
        this.offerPrivatePriceInfo = offerPrivatePriceInfo;
    }

}
