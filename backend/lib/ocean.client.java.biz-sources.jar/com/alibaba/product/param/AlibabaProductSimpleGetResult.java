package com.alibaba.product.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaProductSimpleGetResult {

    private AlibabaProductProductInfo productInfo;

    /**
     * @return 商品详细信息
     */
    public AlibabaProductProductInfo getProductInfo() {
        return productInfo;
    }

    /**
     * 设置商品详细信息     *
          
     * 此参数必填
     */
    public void setProductInfo(AlibabaProductProductInfo productInfo) {
        this.productInfo = productInfo;
    }

    private AlibabaProductProductBizGroupInfo[] bizGroupInfos;

    /**
     * @return 产品业务的支持信息,support为false说明不支持.
     */
    public AlibabaProductProductBizGroupInfo[] getBizGroupInfos() {
        return bizGroupInfos;
    }

    /**
     * 设置产品业务的支持信息,support为false说明不支持.     *
          
     * 此参数必填
     */
    public void setBizGroupInfos(AlibabaProductProductBizGroupInfo[] bizGroupInfos) {
        this.bizGroupInfos = bizGroupInfos;
    }

    private String errMsg;

    /**
     * @return 返回错误信息
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * 设置返回错误信息     *
          
     * 此参数必填
     */
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

}
