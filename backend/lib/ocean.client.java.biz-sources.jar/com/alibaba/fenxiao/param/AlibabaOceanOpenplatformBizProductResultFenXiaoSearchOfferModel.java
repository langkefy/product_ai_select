package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizProductResultFenXiaoSearchOfferModel {

    private AlibabaOceanOpenplatformBizFenxiaoResultCompanyInfo companyInfo;

    /**
     * @return 公司信息
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultCompanyInfo getCompanyInfo() {
        return companyInfo;
    }

    /**
     * 设置公司信息     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setCompanyInfo(AlibabaOceanOpenplatformBizFenxiaoResultCompanyInfo companyInfo) {
        this.companyInfo = companyInfo;
    }

    private Boolean isJxhy;

    /**
     * @return 
     */
    public Boolean getIsJxhy() {
        return isJxhy;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setIsJxhy(Boolean isJxhy) {
        this.isJxhy = isJxhy;
    }

    private Boolean jyFlag;

    /**
     * @return 
     */
    public Boolean getJyFlag() {
        return jyFlag;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setJyFlag(Boolean jyFlag) {
        this.jyFlag = jyFlag;
    }

    private String loginId;

    /**
     * @return 卖家id
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * 设置卖家id     *
     * 参数示例：<pre>aaa</pre>     
     * 此参数必填
     */
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultOfferHistoryTradeInfo[] offerHistoryTradeInfo;

    /**
     * @return 历史交易信息
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultOfferHistoryTradeInfo[] getOfferHistoryTradeInfo() {
        return offerHistoryTradeInfo;
    }

    /**
     * 设置历史交易信息     *
     * 参数示例：<pre>[           {             "historyTradeKey": "GmvValue30DaysFuzzify",             "historyTradeValue": "40+"           },           {             "historyTradeKey": "Sales90Fuzzify",             "historyTradeValue": "100+"           }         ]</pre>     
     * 此参数必填
     */
    public void setOfferHistoryTradeInfo(AlibabaOceanOpenplatformBizFenxiaoResultOfferHistoryTradeInfo[] offerHistoryTradeInfo) {
        this.offerHistoryTradeInfo = offerHistoryTradeInfo;
    }

    private Long offerId;

    /**
     * @return 商品id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>12456584522</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultOfferImage offerImage;

    /**
     * @return 商品图片信息
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultOfferImage getOfferImage() {
        return offerImage;
    }

    /**
     * 设置商品图片信息     *
     * 参数示例：<pre>{"imageUrl":"https://cbu01.alicdn.com/img/ibank/2018/252/506/9038605252_733519461.jpg"}</pre>     
     * 此参数必填
     */
    public void setOfferImage(AlibabaOceanOpenplatformBizFenxiaoResultOfferImage offerImage) {
        this.offerImage = offerImage;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultOfferPrice offerPrice;

    /**
     * @return 商品价格信息
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultOfferPrice getOfferPrice() {
        return offerPrice;
    }

    /**
     * 设置商品价格信息     *
     * 参数示例：<pre>{"consignPrice":"68.00","price":"68.00","priceType":"NORMAL","priceUnderLine":"68.00","quantityPrice":[{"quantity":"2~19","value":"68.00"},{"quantity":"20~99","value":"65.00"},{"quantity":"≥100","value":"63.00"}]}</pre>     
     * 此参数必填
     */
    public void setOfferPrice(AlibabaOceanOpenplatformBizFenxiaoResultOfferPrice offerPrice) {
        this.offerPrice = offerPrice;
    }

    private String offerSuttleWeight;

    /**
     * @return 
     */
    public String getOfferSuttleWeight() {
        return offerSuttleWeight;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setOfferSuttleWeight(String offerSuttleWeight) {
        this.offerSuttleWeight = offerSuttleWeight;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultOfferTradeServiceInfo[] offerTradeServiceInfo;

    /**
     * @return 商品服务
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultOfferTradeServiceInfo[] getOfferTradeServiceInfo() {
        return offerTradeServiceInfo;
    }

    /**
     * 设置商品服务     *
     * 参数示例：<pre>[{"enable":true,"serviceName":"一件代发","serviceTag":"98306","serviceType":"service_char"}]</pre>     
     * 此参数必填
     */
    public void setOfferTradeServiceInfo(AlibabaOceanOpenplatformBizFenxiaoResultOfferTradeServiceInfo[] offerTradeServiceInfo) {
        this.offerTradeServiceInfo = offerTradeServiceInfo;
    }

    private String offerWeight;

    /**
     * @return 
     */
    public String getOfferWeight() {
        return offerWeight;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setOfferWeight(String offerWeight) {
        this.offerWeight = offerWeight;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultQualityEvaluation qualityEvaluation;

    /**
     * @return 商品评价分
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultQualityEvaluation getQualityEvaluation() {
        return qualityEvaluation;
    }

    /**
     * 设置商品评价分     *
     * 参数示例：<pre>{"compositeScore":3.5,"consultationScore":5,"disputeScore":5,"goodsScore":5,"logisticsScore":3,"returnScore":3}</pre>     
     * 此参数必填
     */
    public void setQualityEvaluation(AlibabaOceanOpenplatformBizFenxiaoResultQualityEvaluation qualityEvaluation) {
        this.qualityEvaluation = qualityEvaluation;
    }

    private Integer quantityBegin;

    /**
     * @return 
     */
    public Integer getQuantityBegin() {
        return quantityBegin;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setQuantityBegin(Integer quantityBegin) {
        this.quantityBegin = quantityBegin;
    }

    private String subject;

    /**
     * @return 标题
     */
    public String getSubject() {
        return subject;
    }

    /**
     * 设置标题     *
     * 参数示例：<pre>高档夏棉衬衫商务休闲正装男</pre>     
     * 此参数必填
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    private String unit;

    /**
     * @return 
     */
    public String getUnit() {
        return unit;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setUnit(String unit) {
        this.unit = unit;
    }

    private Long userId;

    /**
     * @return 卖家userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置卖家userId     *
     * 参数示例：<pre>aaa</pre>     
     * 此参数必填
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    private Long openuid;

    /**
     * @return 卖家openuid
     */
    public Long getOpenuid() {
        return openuid;
    }

    /**
     * 设置卖家openuid     *
     * 参数示例：<pre>aaa</pre>     
     * 此参数必填
     */
    public void setOpenuid(Long openuid) {
        this.openuid = openuid;
    }

    private String openUid;

    /**
     * @return 卖家id加密为openUid
     */
    public String getOpenUid() {
        return openUid;
    }

    /**
     * 设置卖家id加密为openUid     *
     * 参数示例：<pre>aaa</pre>     
     * 此参数必填
     */
    public void setOpenUid(String openUid) {
        this.openUid = openUid;
    }

    private String yxScoreLevel;

    /**
     * @return 严选分值等级：YX_SCORE_LEVEL_1-“分销推荐星级：5星”；YX_SCORE_LEVEL_2-“分销推荐星级：4星”
     */
    public String getYxScoreLevel() {
        return yxScoreLevel;
    }

    /**
     * 设置严选分值等级：YX_SCORE_LEVEL_1-“分销推荐星级：5星”；YX_SCORE_LEVEL_2-“分销推荐星级：4星”     *
     * 参数示例：<pre>YX_SCORE_LEVEL_1</pre>     
     * 此参数必填
     */
    public void setYxScoreLevel(String yxScoreLevel) {
        this.yxScoreLevel = yxScoreLevel;
    }

}
