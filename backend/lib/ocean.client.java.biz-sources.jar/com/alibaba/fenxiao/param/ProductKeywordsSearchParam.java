package com.alibaba.fenxiao.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ProductKeywordsSearchParam extends AbstractAPIRequest<ProductKeywordsSearchResult> {

    public ProductKeywordsSearchParam() {
        super();
        oceanApiId = new APIId("com.alibaba.fenxiao", "product.keywords.search", 1);
    }

    private AlibabaOceanOpenplatformBizProductParamFenXiaoKeyWordSearchParam param;

    /**
     * @return 关键词搜索参数
     */
    public AlibabaOceanOpenplatformBizProductParamFenXiaoKeyWordSearchParam getParam() {
        return param;
    }

    /**
     * 设置关键词搜索参数     *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setParam(AlibabaOceanOpenplatformBizProductParamFenXiaoKeyWordSearchParam param) {
        this.param = param;
    }

}
