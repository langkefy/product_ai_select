package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultQuantityPrice {

    private String quantity;

    /**
     * @return 
     */
    public String getQuantity() {
        return quantity;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    private String value;

    /**
     * @return 
     */
    public String getValue() {
        return value;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setValue(String value) {
        this.value = value;
    }

}
