package com.alibaba.fenxiao.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyQueryMonitorProductListParam extends AbstractAPIRequest<FenxiaoSupplyQueryMonitorProductListResult> {

    public FenxiaoSupplyQueryMonitorProductListParam() {
        super();
        oceanApiId = new APIId("com.alibaba.fenxiao", "fenxiao.supply.queryMonitorProductList", 1);
    }

    private AlibabaCbuSupplyParamMonitorProductQueryRequest queryRequest;

    /**
     * @return 查询参数
     */
    public AlibabaCbuSupplyParamMonitorProductQueryRequest getQueryRequest() {
        return queryRequest;
    }

    /**
     * 设置查询参数     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setQueryRequest(AlibabaCbuSupplyParamMonitorProductQueryRequest queryRequest) {
        this.queryRequest = queryRequest;
    }

}
