package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultOfferImage {

    private String imageUrl;

    /**
     * @return 
     */
    public String getImageUrl() {
        return imageUrl;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

}
