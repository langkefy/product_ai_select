package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCbuCommonModelMonitorProductPageResult {

    private AlibabaCbuSupplyModelMonitorProductDTO[] data;

    /**
     * @return 返回值
     */
    public AlibabaCbuSupplyModelMonitorProductDTO[] getData() {
        return data;
    }

    /**
     * 设置返回值     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setData(AlibabaCbuSupplyModelMonitorProductDTO[] data) {
        this.data = data;
    }

    private String errorCode;

    /**
     * @return 错误编码
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * 设置错误编码     *
     * 参数示例：<pre>101</pre>     
     * 此参数必填
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    private String errorInfo;

    /**
     * @return 系统信息
     */
    public String getErrorInfo() {
        return errorInfo;
    }

    /**
     * 设置系统信息     *
     * 参数示例：<pre>系统异常</pre>     
     * 此参数必填
     */
    public void setErrorInfo(String errorInfo) {
        this.errorInfo = errorInfo;
    }

    private Integer pageNum;

    /**
     * @return 分页页数
     */
    public Integer getPageNum() {
        return pageNum;
    }

    /**
     * 设置分页页数     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    private Integer pageSize;

    /**
     * @return 分页大小
     */
    public Integer getPageSize() {
        return pageSize;
    }

    /**
     * 设置分页大小     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    private Integer recordCount;

    /**
     * @return 记录总条数
     */
    public Integer getRecordCount() {
        return recordCount;
    }

    /**
     * 设置记录总条数     *
     * 参数示例：<pre>20</pre>     
     * 此参数必填
     */
    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    private Boolean success;

    /**
     * @return 返回结果
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置返回结果     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    private Integer total;

    /**
     * @return 总条数
     */
    public Integer getTotal() {
        return total;
    }

    /**
     * 设置总条数     *
     * 参数示例：<pre>20</pre>     
     * 此参数必填
     */
    public void setTotal(Integer total) {
        this.total = total;
    }

    private Integer totalPage;

    /**
     * @return 总页数
     */
    public Integer getTotalPage() {
        return totalPage;
    }

    /**
     * 设置总页数     *
     * 参数示例：<pre>2</pre>     
     * 此参数必填
     */
    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

}
