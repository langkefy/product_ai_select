package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultCompanyInfo {

    private String city;

    /**
     * @return 
     */
    public String getCity() {
        return city;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCity(String city) {
        this.city = city;
    }

    private String companyName;

    /**
     * @return 
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    private String creditLevel;

    /**
     * @return 
     */
    public String getCreditLevel() {
        return creditLevel;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCreditLevel(String creditLevel) {
        this.creditLevel = creditLevel;
    }

    private Boolean isFactory;

    /**
     * @return 
     */
    public Boolean getIsFactory() {
        return isFactory;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setIsFactory(Boolean isFactory) {
        this.isFactory = isFactory;
    }

    private String province;

    /**
     * @return 
     */
    public String getProvince() {
        return province;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setProvince(String province) {
        this.province = province;
    }

    private String shopRepurchaseRate;

    /**
     * @return 
     */
    public String getShopRepurchaseRate() {
        return shopRepurchaseRate;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setShopRepurchaseRate(String shopRepurchaseRate) {
        this.shopRepurchaseRate = shopRepurchaseRate;
    }

    private String shopRepurchaseRateLevel;

    /**
     * @return 
     */
    public String getShopRepurchaseRateLevel() {
        return shopRepurchaseRateLevel;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setShopRepurchaseRateLevel(String shopRepurchaseRateLevel) {
        this.shopRepurchaseRateLevel = shopRepurchaseRateLevel;
    }

    private String url;

    /**
     * @return 
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setUrl(String url) {
        this.url = url;
    }

}
