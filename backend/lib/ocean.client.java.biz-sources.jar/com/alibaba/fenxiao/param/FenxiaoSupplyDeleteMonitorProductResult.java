package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyDeleteMonitorProductResult {

    private AlibabaCbuCommonModelDeleteBooleanResult result;

    /**
     * @return 返回结果
     */
    public AlibabaCbuCommonModelDeleteBooleanResult getResult() {
        return result;
    }

    /**
     * 设置返回结果     *
          
     * 此参数必填
     */
    public void setResult(AlibabaCbuCommonModelDeleteBooleanResult result) {
        this.result = result;
    }

}
