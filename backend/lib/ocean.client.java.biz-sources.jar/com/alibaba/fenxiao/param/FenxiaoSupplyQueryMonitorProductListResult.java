package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyQueryMonitorProductListResult {

    private AlibabaCbuCommonModelMonitorProductPageResult result;

    /**
     * @return 返回结果
     */
    public AlibabaCbuCommonModelMonitorProductPageResult getResult() {
        return result;
    }

    /**
     * 设置返回结果     *
          
     * 此参数必填
     */
    public void setResult(AlibabaCbuCommonModelMonitorProductPageResult result) {
        this.result = result;
    }

}
