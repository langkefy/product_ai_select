package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultOfferHistoryTradeInfo {

    private String historyTradeKey;

    /**
     * @return 
     */
    public String getHistoryTradeKey() {
        return historyTradeKey;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setHistoryTradeKey(String historyTradeKey) {
        this.historyTradeKey = historyTradeKey;
    }

    private String historyTradeValue;

    /**
     * @return 
     */
    public String getHistoryTradeValue() {
        return historyTradeValue;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setHistoryTradeValue(String historyTradeValue) {
        this.historyTradeValue = historyTradeValue;
    }

}
