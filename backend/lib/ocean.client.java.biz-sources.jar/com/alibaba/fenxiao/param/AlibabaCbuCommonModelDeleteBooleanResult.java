package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCbuCommonModelDeleteBooleanResult {

    private Boolean data;

    /**
     * @return 返回结果
     */
    public Boolean getData() {
        return data;
    }

    /**
     * 设置返回结果     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setData(Boolean data) {
        this.data = data;
    }

    private String errorCode;

    /**
     * @return 系统异常
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * 设置系统异常     *
     * 参数示例：<pre>101</pre>     
     * 此参数必填
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    private String errorInfo;

    /**
     * @return 错误信息
     */
    public String getErrorInfo() {
        return errorInfo;
    }

    /**
     * 设置错误信息     *
     * 参数示例：<pre>系统异常</pre>     
     * 此参数必填
     */
    public void setErrorInfo(String errorInfo) {
        this.errorInfo = errorInfo;
    }

    private Boolean success;

    /**
     * @return 调用结果
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置调用结果     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

}
