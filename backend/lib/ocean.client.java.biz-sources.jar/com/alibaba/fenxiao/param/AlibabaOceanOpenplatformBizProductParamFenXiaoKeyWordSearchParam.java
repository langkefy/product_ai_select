package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizProductParamFenXiaoKeyWordSearchParam {

    private String[] categoryIds;

    /**
     * @return 限定类目ID列表，从类目搜索接口获取
     */
    public String[] getCategoryIds() {
        return categoryIds;
    }

    /**
     * 设置限定类目ID列表，从类目搜索接口获取     *
     * 参数示例：<pre>["10166"]</pre>     
     * 此参数必填
     */
    public void setCategoryIds(String[] categoryIds) {
        this.categoryIds = categoryIds;
    }

    private String keywords;

    /**
     * @return 搜索关键词 
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * 设置搜索关键词      *
     * 参数示例：<pre>衣服</pre>     
     * 此参数必填
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    private Long pageNum;

    /**
     * @return 当前页码 
     */
    public Long getPageNum() {
        return pageNum;
    }

    /**
     * 设置当前页码      *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setPageNum(Long pageNum) {
        this.pageNum = pageNum;
    }

    private Long pageSize;

    /**
     * @return 分页页大小，默认20最大50 
     */
    public Long getPageSize() {
        return pageSize;
    }

    /**
     * 设置分页页大小，默认20最大50      *
     * 参数示例：<pre>20</pre>     
     * 此参数必填
     */
    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }

    private String priceEnd;

    /**
     * @return 价格区间结束（单位 元）
     */
    public String getPriceEnd() {
        return priceEnd;
    }

    /**
     * 设置价格区间结束（单位 元）     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setPriceEnd(String priceEnd) {
        this.priceEnd = priceEnd;
    }

    private String priceStart;

    /**
     * @return 价格区间开始（单位 元）
     */
    public String getPriceStart() {
        return priceStart;
    }

    /**
     * 设置价格区间开始（单位 元）     *
     * 参数示例：<pre>5</pre>     
     * 此参数必填
     */
    public void setPriceStart(String priceStart) {
        this.priceStart = priceStart;
    }

    private Long quantityBegin;

    /**
     * @return 起批量
     */
    public Long getQuantityBegin() {
        return quantityBegin;
    }

    /**
     * 设置起批量     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setQuantityBegin(Long quantityBegin) {
        this.quantityBegin = quantityBegin;
    }

    private String sortOrder;

    /**
     * @return 
     */
    public String getSortOrder() {
        return sortOrder;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    private String sortType;

    /**
     * @return 
     */
    public String getSortType() {
        return sortType;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    private String[] filter;

    /**
     * @return 过滤参数，fxBrandOffer-1688分销品牌商品黑标，hasAIMaterials-1688分销AI素材商品，严选分值等级：YX_SCORE_LEVEL_1-“分销推荐星级：5星”、YX_SCORE_LEVEL_2-“分销推荐星级：4星”
     */
    public String[] getFilter() {
        return filter;
    }

    /**
     * 设置过滤参数，fxBrandOffer-1688分销品牌商品黑标，hasAIMaterials-1688分销AI素材商品，严选分值等级：YX_SCORE_LEVEL_1-“分销推荐星级：5星”、YX_SCORE_LEVEL_2-“分销推荐星级：4星”     *
     * 参数示例：<pre> ["fxBrandOffer", "hasAIMaterials"]</pre>     
     * 此参数必填
     */
    public void setFilter(String[] filter) {
        this.filter = filter;
    }

}
