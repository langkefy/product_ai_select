package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ProductKeywordsSearchResult {

    private AlibabaOpenapiSharedCommonPageResultModel result;

    /**
     * @return 分销词搜返回模型
     */
    public AlibabaOpenapiSharedCommonPageResultModel getResult() {
        return result;
    }

    /**
     * 设置分销词搜返回模型     *
          
     * 此参数必填
     */
    public void setResult(AlibabaOpenapiSharedCommonPageResultModel result) {
        this.result = result;
    }

}
