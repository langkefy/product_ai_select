package com.alibaba.fenxiao.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyDeleteMonitorProductParam extends AbstractAPIRequest<FenxiaoSupplyDeleteMonitorProductResult> {

    public FenxiaoSupplyDeleteMonitorProductParam() {
        super();
        oceanApiId = new APIId("com.alibaba.fenxiao", "fenxiao.supply.deleteMonitorProduct", 1);
    }

    private AlibabaCbuSupplyParamMonitorProductDeleteRequest deleteRequest;

    /**
     * @return 删除参数
     */
    public AlibabaCbuSupplyParamMonitorProductDeleteRequest getDeleteRequest() {
        return deleteRequest;
    }

    /**
     * 设置删除参数     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setDeleteRequest(AlibabaCbuSupplyParamMonitorProductDeleteRequest deleteRequest) {
        this.deleteRequest = deleteRequest;
    }

}
