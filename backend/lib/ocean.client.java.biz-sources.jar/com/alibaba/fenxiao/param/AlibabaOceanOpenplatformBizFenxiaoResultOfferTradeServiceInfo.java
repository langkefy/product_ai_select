package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultOfferTradeServiceInfo {

    private Boolean enable;

    /**
     * @return 
     */
    public Boolean getEnable() {
        return enable;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    private String serviceName;

    /**
     * @return 
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    private String serviceTag;

    /**
     * @return 
     */
    public String getServiceTag() {
        return serviceTag;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setServiceTag(String serviceTag) {
        this.serviceTag = serviceTag;
    }

    private String serviceType;

    /**
     * @return 
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

}
