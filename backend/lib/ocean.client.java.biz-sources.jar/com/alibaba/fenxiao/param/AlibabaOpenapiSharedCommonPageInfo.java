package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOpenapiSharedCommonPageInfo {

    private Long totalPage;

    /**
     * @return 
     */
    public Long getTotalPage() {
        return totalPage;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setTotalPage(Long totalPage) {
        this.totalPage = totalPage;
    }

    private Long currentPage;

    /**
     * @return 
     */
    public Long getCurrentPage() {
        return currentPage;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCurrentPage(Long currentPage) {
        this.currentPage = currentPage;
    }

    private Long pageSize;

    /**
     * @return 
     */
    public Long getPageSize() {
        return pageSize;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }

    private Long totalRecords;

    /**
     * @return 
     */
    public Long getTotalRecords() {
        return totalRecords;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setTotalRecords(Long totalRecords) {
        this.totalRecords = totalRecords;
    }

}
