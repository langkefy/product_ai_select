package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultFenxiaoPrice {

    private Boolean freepostage;

    /**
     * @return 
     */
    public Boolean getFreepostage() {
        return freepostage;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setFreepostage(Boolean freepostage) {
        this.freepostage = freepostage;
    }

    private String pfPrice;

    /**
     * @return 
     */
    public String getPfPrice() {
        return pfPrice;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPfPrice(String pfPrice) {
        this.pfPrice = pfPrice;
    }

    private String price;

    /**
     * @return 
     */
    public String getPrice() {
        return price;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPrice(String price) {
        this.price = price;
    }

}
