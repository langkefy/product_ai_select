package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOpenapiSharedCommonPageResultModel {

    private Boolean success;

    /**
     * @return 
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    private String code;

    /**
     * @return 
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCode(String code) {
        this.code = code;
    }

    private String message;

    /**
     * @return 
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setMessage(String message) {
        this.message = message;
    }

    private AlibabaOceanOpenplatformBizProductResultFenXiaoSearchOfferModel[] result;

    /**
     * @return 
     */
    public AlibabaOceanOpenplatformBizProductResultFenXiaoSearchOfferModel[] getResult() {
        return result;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setResult(AlibabaOceanOpenplatformBizProductResultFenXiaoSearchOfferModel[] result) {
        this.result = result;
    }

    private AlibabaOpenapiSharedCommonPageInfo pageInfo;

    /**
     * @return 
     */
    public AlibabaOpenapiSharedCommonPageInfo getPageInfo() {
        return pageInfo;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPageInfo(AlibabaOpenapiSharedCommonPageInfo pageInfo) {
        this.pageInfo = pageInfo;
    }

}
