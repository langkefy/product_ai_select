package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyAddMonitorProductResult {

    private AlibabaCbuCommonModelMonitorProductResult result;

    /**
     * @return 返回值
     */
    public AlibabaCbuCommonModelMonitorProductResult getResult() {
        return result;
    }

    /**
     * 设置返回值     *
          
     * 此参数必填
     */
    public void setResult(AlibabaCbuCommonModelMonitorProductResult result) {
        this.result = result;
    }

}
