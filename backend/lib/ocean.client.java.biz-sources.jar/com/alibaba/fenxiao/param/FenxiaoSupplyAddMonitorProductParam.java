package com.alibaba.fenxiao.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class FenxiaoSupplyAddMonitorProductParam extends AbstractAPIRequest<FenxiaoSupplyAddMonitorProductResult> {

    public FenxiaoSupplyAddMonitorProductParam() {
        super();
        oceanApiId = new APIId("com.alibaba.fenxiao", "fenxiao.supply.addMonitorProduct", 1);
    }

    private AlibabaCbuSupplyParamMonitorProductAddRequest addRequest;

    /**
     * @return 添加监控商品参数
     */
    public AlibabaCbuSupplyParamMonitorProductAddRequest getAddRequest() {
        return addRequest;
    }

    /**
     * 设置添加监控商品参数     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setAddRequest(AlibabaCbuSupplyParamMonitorProductAddRequest addRequest) {
        this.addRequest = addRequest;
    }

}
