package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCbuSupplyParamMonitorProductDeleteRequest {

    private Long offerId;

    /**
     * @return 商品id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private long[] skuIds;

    /**
     * @return skuIds
     */
    public long[] getSkuIds() {
        return skuIds;
    }

    /**
     * 设置skuIds     *
     * 参数示例：<pre>-</pre>     
     * 此参数必填
     */
    public void setSkuIds(long[] skuIds) {
        this.skuIds = skuIds;
    }

}
