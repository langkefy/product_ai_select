package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCbuSupplyParamMonitorProductQueryRequest {

    private String appKey;

    /**
     * @return isv的appKey
     */
    public String getAppKey() {
        return appKey;
    }

    /**
     * 设置isv的appKey     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    private Long buyerUserId;

    /**
     * @return 买家用户id
     */
    public Long getBuyerUserId() {
        return buyerUserId;
    }

    /**
     * 设置买家用户id     *
     * 参数示例：<pre>3456</pre>     
     * 此参数必填
     */
    public void setBuyerUserId(Long buyerUserId) {
        this.buyerUserId = buyerUserId;
    }

    private Long offerId;

    /**
     * @return 商品id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>11111</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private Integer pageNum;

    /**
     * @return 分页页数
     */
    public Integer getPageNum() {
        return pageNum;
    }

    /**
     * 设置分页页数     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    private Integer pageSize;

    /**
     * @return 分页大小
     */
    public Integer getPageSize() {
        return pageSize;
    }

    /**
     * 设置分页大小     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
