package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultOfferPrice {

    private String consignPrice;

    /**
     * @return 
     */
    public String getConsignPrice() {
        return consignPrice;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setConsignPrice(String consignPrice) {
        this.consignPrice = consignPrice;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultFenxiaoPrice fenxiaoPrice;

    /**
     * @return 
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultFenxiaoPrice getFenxiaoPrice() {
        return fenxiaoPrice;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setFenxiaoPrice(AlibabaOceanOpenplatformBizFenxiaoResultFenxiaoPrice fenxiaoPrice) {
        this.fenxiaoPrice = fenxiaoPrice;
    }

    private String price;

    /**
     * @return 
     */
    public String getPrice() {
        return price;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPrice(String price) {
        this.price = price;
    }

    private String priceType;

    /**
     * @return 
     */
    public String getPriceType() {
        return priceType;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPriceType(String priceType) {
        this.priceType = priceType;
    }

    private String priceUnderLine;

    /**
     * @return 
     */
    public String getPriceUnderLine() {
        return priceUnderLine;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPriceUnderLine(String priceUnderLine) {
        this.priceUnderLine = priceUnderLine;
    }

    private AlibabaOceanOpenplatformBizFenxiaoResultQuantityPrice[] quantityPrice;

    /**
     * @return 
     */
    public AlibabaOceanOpenplatformBizFenxiaoResultQuantityPrice[] getQuantityPrice() {
        return quantityPrice;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setQuantityPrice(AlibabaOceanOpenplatformBizFenxiaoResultQuantityPrice[] quantityPrice) {
        this.quantityPrice = quantityPrice;
    }

    private String multipleConsignPrice;

    /**
     * @return 分销多件下单价格（单位：元）
     */
    public String getMultipleConsignPrice() {
        return multipleConsignPrice;
    }

    /**
     * 设置分销多件下单价格（单位：元）     *
     * 参数示例：<pre>11.90</pre>     
     * 此参数必填
     */
    public void setMultipleConsignPrice(String multipleConsignPrice) {
        this.multipleConsignPrice = multipleConsignPrice;
    }

    private Boolean distributionFreePostage;

    /**
     * @return 分销是否包邮
     */
    public Boolean getDistributionFreePostage() {
        return distributionFreePostage;
    }

    /**
     * 设置分销是否包邮     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setDistributionFreePostage(Boolean distributionFreePostage) {
        this.distributionFreePostage = distributionFreePostage;
    }

}
