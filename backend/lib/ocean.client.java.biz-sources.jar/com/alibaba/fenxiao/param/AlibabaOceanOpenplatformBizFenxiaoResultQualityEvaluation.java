package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizFenxiaoResultQualityEvaluation {

    private Double compositeScore;

    /**
     * @return 
     */
    public Double getCompositeScore() {
        return compositeScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCompositeScore(Double compositeScore) {
        this.compositeScore = compositeScore;
    }

    private Double consultationScore;

    /**
     * @return 
     */
    public Double getConsultationScore() {
        return consultationScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setConsultationScore(Double consultationScore) {
        this.consultationScore = consultationScore;
    }

    private Double disputeScore;

    /**
     * @return 
     */
    public Double getDisputeScore() {
        return disputeScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setDisputeScore(Double disputeScore) {
        this.disputeScore = disputeScore;
    }

    private Double goodsScore;

    /**
     * @return 
     */
    public Double getGoodsScore() {
        return goodsScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setGoodsScore(Double goodsScore) {
        this.goodsScore = goodsScore;
    }

    private Double logisticsScore;

    /**
     * @return 
     */
    public Double getLogisticsScore() {
        return logisticsScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setLogisticsScore(Double logisticsScore) {
        this.logisticsScore = logisticsScore;
    }

    private Double returnScore;

    /**
     * @return 
     */
    public Double getReturnScore() {
        return returnScore;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setReturnScore(Double returnScore) {
        this.returnScore = returnScore;
    }

}
