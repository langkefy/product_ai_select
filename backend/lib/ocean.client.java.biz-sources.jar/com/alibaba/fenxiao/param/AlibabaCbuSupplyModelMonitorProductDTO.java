package com.alibaba.fenxiao.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCbuSupplyModelMonitorProductDTO {

    private Long id;

    /**
     * @return 监控id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置监控id     *
     * 参数示例：<pre>1111</pre>     
     * 此参数必填
     */
    public void setId(Long id) {
        this.id = id;
    }

    private Long offerId;

    /**
     * @return 商品id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>111111</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private String skuIds;

    /**
     * @return 商品skuId
     */
    public String getSkuIds() {
        return skuIds;
    }

    /**
     * 设置商品skuId     *
     * 参数示例：<pre>123,456</pre>     
     * 此参数必填
     */
    public void setSkuIds(String skuIds) {
        this.skuIds = skuIds;
    }

    private Integer status;

    /**
     * @return 监控状态
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置监控状态     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

}
