package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeRefundResultOpQueryOrderRefund {

    private AlibabaTradeRefundOpOrderRefundModel opOrderRefundModelDetail;

    /**
     * @return 返回值
     */
    public AlibabaTradeRefundOpOrderRefundModel getOpOrderRefundModelDetail() {
        return opOrderRefundModelDetail;
    }

    /**
     * 设置返回值     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setOpOrderRefundModelDetail(AlibabaTradeRefundOpOrderRefundModel opOrderRefundModelDetail) {
        this.opOrderRefundModelDetail = opOrderRefundModelDetail;
    }

}
