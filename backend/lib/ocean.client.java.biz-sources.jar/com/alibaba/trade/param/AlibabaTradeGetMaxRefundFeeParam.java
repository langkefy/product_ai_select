package com.alibaba.trade.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeGetMaxRefundFeeParam extends AbstractAPIRequest<AlibabaTradeGetMaxRefundFeeResult> {

    public AlibabaTradeGetMaxRefundFeeParam() {
        super();
        oceanApiId = new APIId("com.alibaba.trade", "alibaba.trade.getMaxRefundFee", 1);
    }

    private AlibabaOceanOpenplatformBizTradeParamOpMaxRefundFeeGetParam input;

    /**
     * @return  
     */
    public AlibabaOceanOpenplatformBizTradeParamOpMaxRefundFeeGetParam getInput() {
        return input;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setInput(AlibabaOceanOpenplatformBizTradeParamOpMaxRefundFeeGetParam input) {
        this.input = input;
    }

}
