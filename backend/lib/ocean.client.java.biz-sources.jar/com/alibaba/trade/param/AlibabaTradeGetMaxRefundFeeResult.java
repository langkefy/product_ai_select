package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeGetMaxRefundFeeResult {

    private AlibabaOceanOpenplatformCommonOpMaxRefundFeeResultModel result;

    /**
     * @return  
     */
    public AlibabaOceanOpenplatformCommonOpMaxRefundFeeResultModel getResult() {
        return result;
    }

    /**
     * 设置      *
          
     * 此参数必填
     */
    public void setResult(AlibabaOceanOpenplatformCommonOpMaxRefundFeeResultModel result) {
        this.result = result;
    }

}
