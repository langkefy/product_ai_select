package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelTradeServiceGroup {

    private String outId;

    /**
     * @return id
     */
    public String getOutId() {
        return outId;
    }

    /**
     * 设置id     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setOutId(String outId) {
        this.outId = outId;
    }

    private String groupTitle;

    /**
     * @return 组名称
     */
    public String getGroupTitle() {
        return groupTitle;
    }

    /**
     * 设置组名称     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setGroupTitle(String groupTitle) {
        this.groupTitle = groupTitle;
    }

    private String groupCode;

    /**
     * @return 组编码
     */
    public String getGroupCode() {
        return groupCode;
    }

    /**
     * 设置组编码     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    private String groupDescLink;

    /**
     * @return 组描述链接
     */
    public String getGroupDescLink() {
        return groupDescLink;
    }

    /**
     * 设置组描述链接     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setGroupDescLink(String groupDescLink) {
        this.groupDescLink = groupDescLink;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelTradeService[] tradeServiceList;

    /**
     * @return 服务信息
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelTradeService[] getTradeServiceList() {
        return tradeServiceList;
    }

    /**
     * 设置服务信息     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setTradeServiceList(ComAlibabaOceanOpenplatformBizTradeCommonModelTradeService[] tradeServiceList) {
        this.tradeServiceList = tradeServiceList;
    }

    private String extraMapStr;

    /**
     * @return 扩展信息
     */
    public String getExtraMapStr() {
        return extraMapStr;
    }

    /**
     * 设置扩展信息     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setExtraMapStr(String extraMapStr) {
        this.extraMapStr = extraMapStr;
    }

    private Long combinedPrice;

    /**
     * @return 合并价格
     */
    public Long getCombinedPrice() {
        return combinedPrice;
    }

    /**
     * 设置合并价格     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setCombinedPrice(Long combinedPrice) {
        this.combinedPrice = combinedPrice;
    }

    private String showCombinedPrice;

    /**
     * @return 展示合并价格
     */
    public String getShowCombinedPrice() {
        return showCombinedPrice;
    }

    /**
     * 设置展示合并价格     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setShowCombinedPrice(String showCombinedPrice) {
        this.showCombinedPrice = showCombinedPrice;
    }

}
