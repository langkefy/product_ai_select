package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeParamTradeService {

    private String code;

    /**
     * @return 交易服务code
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置交易服务code     *
     * 参数示例：<pre>vas</pre>     
     * 此参数必填
     */
    public void setCode(String code) {
        this.code = code;
    }

    private String sourceId;

    /**
     * @return 交易服务sourceId
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * 设置交易服务sourceId     *
     * 参数示例：<pre>3C</pre>     
     * 此参数必填
     */
    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

}
