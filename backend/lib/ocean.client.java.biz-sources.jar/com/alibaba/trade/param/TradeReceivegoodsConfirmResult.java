package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class TradeReceivegoodsConfirmResult {

    private AlibabaOceanOpenplatformBizTradeResultTradeConfirmReceiptResult result;

    /**
     * @return 
     */
    public AlibabaOceanOpenplatformBizTradeResultTradeConfirmReceiptResult getResult() {
        return result;
    }

    /**
     * 设置     *
          
     * 此参数必填
     */
    public void setResult(AlibabaOceanOpenplatformBizTradeResultTradeConfirmReceiptResult result) {
        this.result = result;
    }

}
