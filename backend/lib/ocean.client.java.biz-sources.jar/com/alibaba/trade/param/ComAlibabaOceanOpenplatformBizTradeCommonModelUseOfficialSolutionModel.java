package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelUseOfficialSolutionModel {

    private String orderGroup;

    /**
     * @return 订单分组
     */
    public String getOrderGroup() {
        return orderGroup;
    }

    /**
     * 设置订单分组     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOrderGroup(String orderGroup) {
        this.orderGroup = orderGroup;
    }

    private String useOfficialSolutionCode;

    /**
     * @return 官方物流提货物流解决方案编码
     */
    public String getUseOfficialSolutionCode() {
        return useOfficialSolutionCode;
    }

    /**
     * 设置官方物流提货物流解决方案编码     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setUseOfficialSolutionCode(String useOfficialSolutionCode) {
        this.useOfficialSolutionCode = useOfficialSolutionCode;
    }

}
