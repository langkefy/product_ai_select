package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class BizFenXiaoOutSubOrderInfo {

    private String outSubOrderId;

    /**
     * @return 下游子订单号
     */
    public String getOutSubOrderId() {
        return outSubOrderId;
    }

    /**
     * 设置下游子订单号     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutSubOrderId(String outSubOrderId) {
        this.outSubOrderId = outSubOrderId;
    }

    private String outSkuId;

    /**
     * @return 下游skuId
     */
    public String getOutSkuId() {
        return outSkuId;
    }

    /**
     * 设置下游skuId     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutSkuId(String outSkuId) {
        this.outSkuId = outSkuId;
    }

    private Double outSubGmv;

    /**
     * @return 下游子订单GMV
     */
    public Double getOutSubGmv() {
        return outSubGmv;
    }

    /**
     * 设置下游子订单GMV     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutSubGmv(Double outSubGmv) {
        this.outSubGmv = outSubGmv;
    }

    private Double outSubQty;

    /**
     * @return 下游子订单数量
     */
    public Double getOutSubQty() {
        return outSubQty;
    }

    /**
     * 设置下游子订单数量     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutSubQty(Double outSubQty) {
        this.outSubQty = outSubQty;
    }

    private String outSubOrderPayTime;

    /**
     * @return 下游子订单时间
     */
    public String getOutSubOrderPayTime() {
        return outSubOrderPayTime;
    }

    /**
     * 设置下游子订单时间     *
     * 参数示例：<pre>2025-03-18 09:20:21</pre>     
     * 此参数必填
     */
    public void setOutSubOrderPayTime(String outSubOrderPayTime) {
        this.outSubOrderPayTime = outSubOrderPayTime;
    }

    private String outSubOrderLatestDeliveryTime;

    /**
     * @return 下游子订单最晚发货时间
     */
    public String getOutSubOrderLatestDeliveryTime() {
        return outSubOrderLatestDeliveryTime;
    }

    /**
     * 设置下游子订单最晚发货时间     *
     * 参数示例：<pre>2025-03-18 09:20:21</pre>     
     * 此参数必填
     */
    public void setOutSubOrderLatestDeliveryTime(String outSubOrderLatestDeliveryTime) {
        this.outSubOrderLatestDeliveryTime = outSubOrderLatestDeliveryTime;
    }

    private Double outSubGmvDiscount;

    /**
     * @return 下游子订单优惠金额
     */
    public Double getOutSubGmvDiscount() {
        return outSubGmvDiscount;
    }

    /**
     * 设置下游子订单优惠金额     *
     * 参数示例：<pre>10</pre>     
     * 此参数必填
     */
    public void setOutSubGmvDiscount(Double outSubGmvDiscount) {
        this.outSubGmvDiscount = outSubGmvDiscount;
    }

    private Double outSubGmvPost;

    /**
     * @return 下游子订单邮费
     */
    public Double getOutSubGmvPost() {
        return outSubGmvPost;
    }

    /**
     * 设置下游子订单邮费     *
     * 参数示例：<pre>5</pre>     
     * 此参数必填
     */
    public void setOutSubGmvPost(Double outSubGmvPost) {
        this.outSubGmvPost = outSubGmvPost;
    }

    private Double outSubGmvReceive;

    /**
     * @return 下游子订单实收金额
     */
    public Double getOutSubGmvReceive() {
        return outSubGmvReceive;
    }

    /**
     * 设置下游子订单实收金额     *
     * 参数示例：<pre>118</pre>     
     * 此参数必填
     */
    public void setOutSubGmvReceive(Double outSubGmvReceive) {
        this.outSubGmvReceive = outSubGmvReceive;
    }

}
