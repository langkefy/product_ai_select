package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformCommonKeyValuePair {

    private String description;

    /**
     * @return 
     */
    public String getDescription() {
        return description;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setDescription(String description) {
        this.description = description;
    }

    private String key;

    /**
     * @return 
     */
    public String getKey() {
        return key;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setKey(String key) {
        this.key = key;
    }

    private String value;

    /**
     * @return 
     */
    public String getValue() {
        return value;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setValue(String value) {
        this.value = value;
    }

}
