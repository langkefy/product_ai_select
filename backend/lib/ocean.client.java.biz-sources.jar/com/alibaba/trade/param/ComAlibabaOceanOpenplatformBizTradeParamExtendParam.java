package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeParamExtendParam {

    private String outShopIdInner;

    /**
     * @return 下游平台店铺id
     */
    public String getOutShopIdInner() {
        return outShopIdInner;
    }

    /**
     * 设置下游平台店铺id     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutShopIdInner(String outShopIdInner) {
        this.outShopIdInner = outShopIdInner;
    }

    private String outShopNameInner;

    /**
     * @return 下游平台店铺名称
     */
    public String getOutShopNameInner() {
        return outShopNameInner;
    }

    /**
     * 设置下游平台店铺名称     *
     * 参数示例：<pre>test123</pre>     
     * 此参数必填
     */
    public void setOutShopNameInner(String outShopNameInner) {
        this.outShopNameInner = outShopNameInner;
    }

    private ComAlibabaOceanOpenplatformBizTradeParamCrossBorderLogisticsSelfPickupAddress crossBorderLogisticsSelfPickupAddress;

    /**
     * @return 跨境集运仓自提点地址和联系人
     */
    public ComAlibabaOceanOpenplatformBizTradeParamCrossBorderLogisticsSelfPickupAddress getCrossBorderLogisticsSelfPickupAddress() {
        return crossBorderLogisticsSelfPickupAddress;
    }

    /**
     * 设置跨境集运仓自提点地址和联系人     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setCrossBorderLogisticsSelfPickupAddress(
            ComAlibabaOceanOpenplatformBizTradeParamCrossBorderLogisticsSelfPickupAddress crossBorderLogisticsSelfPickupAddress) {
        this.crossBorderLogisticsSelfPickupAddress = crossBorderLogisticsSelfPickupAddress;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] extPairList;

    /**
     * @return 扩展对象列表
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] getExtPairList() {
        return extPairList;
    }

    /**
     * 设置扩展对象列表     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setExtPairList(ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] extPairList) {
        this.extPairList = extPairList;
    }

    private AlibabaOceanOpenplatformCommonKeyValuePair[] offerIsvCargoFromList;

    /**
     * @return 轻应用闭环下单，offer来源信息列表
     */
    public AlibabaOceanOpenplatformCommonKeyValuePair[] getOfferIsvCargoFromList() {
        return offerIsvCargoFromList;
    }

    /**
     * 设置轻应用闭环下单，offer来源信息列表     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setOfferIsvCargoFromList(AlibabaOceanOpenplatformCommonKeyValuePair[] offerIsvCargoFromList) {
        this.offerIsvCargoFromList = offerIsvCargoFromList;
    }

    private ComAlibabaOceanOpenplatformBizTradeParamTradeService[] selectedTradeServiceList;

    /**
     * @return 交易服务参数 
     */
    public ComAlibabaOceanOpenplatformBizTradeParamTradeService[] getSelectedTradeServiceList() {
        return selectedTradeServiceList;
    }

    /**
     * 设置交易服务参数      *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setSelectedTradeServiceList(ComAlibabaOceanOpenplatformBizTradeParamTradeService[] selectedTradeServiceList) {
        this.selectedTradeServiceList = selectedTradeServiceList;
    }

}
