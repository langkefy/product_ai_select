package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOrderBizInfo {

    private Boolean odsCyd;

    /**
     * @return 是否采源宝订单
     */
    public Boolean getOdsCyd() {
        return odsCyd;
    }

    /**
     * 设置是否采源宝订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setOdsCyd(Boolean odsCyd) {
        this.odsCyd = odsCyd;
    }

    private String accountPeriodTime;

    /**
     * @return 账期交易订单的到账时间
     */
    public String getAccountPeriodTime() {
        return accountPeriodTime;
    }

    /**
     * 设置账期交易订单的到账时间     *
     * 参数示例：<pre>yyyy-MM-dd HH:mm:ss</pre>     
     * 此参数必填
     */
    public void setAccountPeriodTime(String accountPeriodTime) {
        this.accountPeriodTime = accountPeriodTime;
    }

    private Boolean creditOrder;

    /**
     * @return 为true，表示下单时选择了诚e赊交易方式。注意不等同于“诚e赊支付”，支付时有可能是支付宝付款，具体支付方式查询tradeTerms.payWay
     */
    public Boolean getCreditOrder() {
        return creditOrder;
    }

    /**
     * 设置为true，表示下单时选择了诚e赊交易方式。注意不等同于“诚e赊支付”，支付时有可能是支付宝付款，具体支付方式查询tradeTerms.payWay     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setCreditOrder(Boolean creditOrder) {
        this.creditOrder = creditOrder;
    }

    private AlibabaCreditOrderForDetail creditOrderDetail;

    /**
     * @return 诚e赊支付详情，只有使用诚e赊付款时返回
     */
    public AlibabaCreditOrderForDetail getCreditOrderDetail() {
        return creditOrderDetail;
    }

    /**
     * 设置诚e赊支付详情，只有使用诚e赊付款时返回     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setCreditOrderDetail(AlibabaCreditOrderForDetail creditOrderDetail) {
        this.creditOrderDetail = creditOrderDetail;
    }

    private AlibabaOrderPreOrderForRead preOrderInfo;

    /**
     * @return 预订单信息
     */
    public AlibabaOrderPreOrderForRead getPreOrderInfo() {
        return preOrderInfo;
    }

    /**
     * 设置预订单信息     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setPreOrderInfo(AlibabaOrderPreOrderForRead preOrderInfo) {
        this.preOrderInfo = preOrderInfo;
    }

    private AlibabaLstTradeInfo lstOrderInfo;

    /**
     * @return 零售通订单信息
     */
    public AlibabaLstTradeInfo getLstOrderInfo() {
        return lstOrderInfo;
    }

    /**
     * 设置零售通订单信息     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setLstOrderInfo(AlibabaLstTradeInfo lstOrderInfo) {
        this.lstOrderInfo = lstOrderInfo;
    }

    private String erpBuyerUserId;

    /**
     * @return ERP的用户ID
     */
    public String getErpBuyerUserId() {
        return erpBuyerUserId;
    }

    /**
     * 设置ERP的用户ID     *
     * 参数示例：<pre>U001012121</pre>     
     * 此参数必填
     */
    public void setErpBuyerUserId(String erpBuyerUserId) {
        this.erpBuyerUserId = erpBuyerUserId;
    }

    private String erpOrderId;

    /**
     * @return ERP的订单编号
     */
    public String getErpOrderId() {
        return erpOrderId;
    }

    /**
     * 设置ERP的订单编号     *
     * 参数示例：<pre>O123331</pre>     
     * 此参数必填
     */
    public void setErpOrderId(String erpOrderId) {
        this.erpOrderId = erpOrderId;
    }

    private String erpBuyerOrgId;

    /**
     * @return ERP组织ID
     */
    public String getErpBuyerOrgId() {
        return erpBuyerOrgId;
    }

    /**
     * 设置ERP组织ID     *
     * 参数示例：<pre>OG4331113</pre>     
     * 此参数必填
     */
    public void setErpBuyerOrgId(String erpBuyerOrgId) {
        this.erpBuyerOrgId = erpBuyerOrgId;
    }

    private Boolean isCz;

    /**
     * @return 是否加工定制订单
     */
    public Boolean getIsCz() {
        return isCz;
    }

    /**
     * 设置是否加工定制订单     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setIsCz(Boolean isCz) {
        this.isCz = isCz;
    }

    private Boolean isDz;

    /**
     * @return 是否定制订单
     */
    public Boolean getIsDz() {
        return isDz;
    }

    /**
     * 设置是否定制订单     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setIsDz(Boolean isDz) {
        this.isDz = isDz;
    }

    private Boolean dz;

    /**
     * @return 是否定制订单
     */
    public Boolean getDz() {
        return dz;
    }

    /**
     * 设置是否定制订单     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setDz(Boolean dz) {
        this.dz = dz;
    }

    private Boolean dropshipping;

    /**
     * @return 是否dropshipping订单，该类型订单不允许合并发货
     */
    public Boolean getDropshipping() {
        return dropshipping;
    }

    /**
     * 设置是否dropshipping订单，该类型订单不允许合并发货     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setDropshipping(Boolean dropshipping) {
        this.dropshipping = dropshipping;
    }

    private String shippingInsurance;

    /**
     * @return givenByPlatform:平台赠送运费险 givenByMerchant:商家赠送运费险，为空表示订单无运费险
     */
    public String getShippingInsurance() {
        return shippingInsurance;
    }

    /**
     * 设置givenByPlatform:平台赠送运费险 givenByMerchant:商家赠送运费险，为空表示订单无运费险     *
     * 参数示例：<pre>givenByPlatform</pre>     
     * 此参数必填
     */
    public void setShippingInsurance(String shippingInsurance) {
        this.shippingInsurance = shippingInsurance;
    }

    private Boolean hyperLinkCangFaOrder;

    /**
     * @return 大店仓发订单
     */
    public Boolean getHyperLinkCangFaOrder() {
        return hyperLinkCangFaOrder;
    }

    /**
     * 设置大店仓发订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setHyperLinkCangFaOrder(Boolean hyperLinkCangFaOrder) {
        this.hyperLinkCangFaOrder = hyperLinkCangFaOrder;
    }

    private Boolean hyperLinkOrder;

    /**
     * @return 超链一阶段订单
     */
    public Boolean getHyperLinkOrder() {
        return hyperLinkOrder;
    }

    /**
     * 设置超链一阶段订单     *
     * 参数示例：<pre>flase</pre>     
     * 此参数必填
     */
    public void setHyperLinkOrder(Boolean hyperLinkOrder) {
        this.hyperLinkOrder = hyperLinkOrder;
    }

    private Boolean hyperLinkSecondStepOrder;

    /**
     * @return 超链大店二阶段订单的第二阶段订单
     */
    public Boolean getHyperLinkSecondStepOrder() {
        return hyperLinkSecondStepOrder;
    }

    /**
     * 设置超链大店二阶段订单的第二阶段订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setHyperLinkSecondStepOrder(Boolean hyperLinkSecondStepOrder) {
        this.hyperLinkSecondStepOrder = hyperLinkSecondStepOrder;
    }

    private String hyperLinkShipType;

    /**
     * @return 超链一阶段订单的发货模式 1 仓发 2 商发
     */
    public String getHyperLinkShipType() {
        return hyperLinkShipType;
    }

    /**
     * 设置超链一阶段订单的发货模式 1 仓发 2 商发     *
     * 参数示例：<pre>0</pre>     
     * 此参数必填
     */
    public void setHyperLinkShipType(String hyperLinkShipType) {
        this.hyperLinkShipType = hyperLinkShipType;
    }

    private Boolean lightningWarehouse;

    /**
     * @return 闪电仓订单
     */
    public Boolean getLightningWarehouse() {
        return lightningWarehouse;
    }

    /**
     * 设置闪电仓订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setLightningWarehouse(Boolean lightningWarehouse) {
        this.lightningWarehouse = lightningWarehouse;
    }

    private Boolean aeDoorPickUp;

    /**
     * @return ae上门揽订单
     */
    public Boolean getAeDoorPickUp() {
        return aeDoorPickUp;
    }

    /**
     * 设置ae上门揽订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setAeDoorPickUp(Boolean aeDoorPickUp) {
        this.aeDoorPickUp = aeDoorPickUp;
    }

    private Boolean aeSelfSend;

    /**
     * @return ae自寄订单	
     */
    public Boolean getAeSelfSend() {
        return aeSelfSend;
    }

    /**
     * 设置ae自寄订单	     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setAeSelfSend(Boolean aeSelfSend) {
        this.aeSelfSend = aeSelfSend;
    }

    private Boolean officialPickUp;

    /**
     * @return 官方物流提货
     */
    public Boolean getOfficialPickUp() {
        return officialPickUp;
    }

    /**
     * 设置官方物流提货     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setOfficialPickUp(Boolean officialPickUp) {
        this.officialPickUp = officialPickUp;
    }

    private Boolean fz;

    /**
     * @return 分账订单
     */
    public Boolean getFz() {
        return fz;
    }

    /**
     * 设置分账订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setFz(Boolean fz) {
        this.fz = fz;
    }

    private Boolean tgOfficialPickUp;

    /**
     * @return 托管官方上门揽订单
     */
    public Boolean getTgOfficialPickUp() {
        return tgOfficialPickUp;
    }

    /**
     * 设置托管官方上门揽订单     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setTgOfficialPickUp(Boolean tgOfficialPickUp) {
        this.tgOfficialPickUp = tgOfficialPickUp;
    }

    private Boolean ycdf;

    /**
     * @return 产地云仓代发订单
     */
    public Boolean getYcdf() {
        return ycdf;
    }

    /**
     * 设置产地云仓代发订单     *
     * 参数示例：<pre>true(产地云仓代发订单，仅需在约定的时间内完成备货，等待三方云仓服务商上门完成取件即可，无需自行打单发货)</pre>     
     * 此参数必填
     */
    public void setYcdf(Boolean ycdf) {
        this.ycdf = ycdf;
    }

}
