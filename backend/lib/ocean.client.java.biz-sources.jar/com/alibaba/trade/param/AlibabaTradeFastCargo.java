package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeFastCargo {

    private Long offerId;

    /**
     * @return 商品对应的offer id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品对应的offer id     *
     * 参数示例：<pre>554456348334</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private String openOfferId;

    /**
     * @return 加密offerId，当搜索返回只有openOfferId时，需采用openOfferId替代offerId下单
     */
    public String getOpenOfferId() {
        return openOfferId;
    }

    /**
     * 设置加密offerId，当搜索返回只有openOfferId时，需采用openOfferId替代offerId下单     *
     * 参数示例：<pre>Wcv2w970KoL1BCpJGQp3vwKvcBThOPlpHnUtkK3T0n4=</pre>     
     * 此参数必填
     */
    public void setOpenOfferId(String openOfferId) {
        this.openOfferId = openOfferId;
    }

    private String specId;

    /**
     * @return 商品规格id
     */
    public String getSpecId() {
        return specId;
    }

    /**
     * 设置商品规格id     *
     * 参数示例：<pre>b266e0726506185beaf205cbae88530d</pre>     
     * 此参数必填
     */
    public void setSpecId(String specId) {
        this.specId = specId;
    }

    private Double quantity;

    /**
     * @return 商品数量(计算金额用)
     */
    public Double getQuantity() {
        return quantity;
    }

    /**
     * 设置商品数量(计算金额用)     *
     * 参数示例：<pre>5</pre>     
     * 此参数必填
     */
    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    private String outMemberId;

    /**
     * @return 外部下游会员ID
     */
    public String getOutMemberId() {
        return outMemberId;
    }

    /**
     * 设置外部下游会员ID     *
     * 参数示例：<pre>98928912-23</pre>     
     * 此参数必填
     */
    public void setOutMemberId(String outMemberId) {
        this.outMemberId = outMemberId;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelBizFenXiaoOutSubOrderInfo[] bizFenXiaoOutSubOrderInfo;

    /**
     * @return 分销下游子单数据
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelBizFenXiaoOutSubOrderInfo[] getBizFenXiaoOutSubOrderInfo() {
        return bizFenXiaoOutSubOrderInfo;
    }

    /**
     * 设置分销下游子单数据     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setBizFenXiaoOutSubOrderInfo(ComAlibabaOceanOpenplatformBizTradeCommonModelBizFenXiaoOutSubOrderInfo[] bizFenXiaoOutSubOrderInfo) {
        this.bizFenXiaoOutSubOrderInfo = bizFenXiaoOutSubOrderInfo;
    }

    private String outItemCode;

    /**
     * @return 外部渠道商品编码
     */
    public String getOutItemCode() {
        return outItemCode;
    }

    /**
     * 设置外部渠道商品编码     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutItemCode(String outItemCode) {
        this.outItemCode = outItemCode;
    }

    private String offerChannelToken;

    /**
     * @return offer渠道token
     */
    public String getOfferChannelToken() {
        return offerChannelToken;
    }

    /**
     * 设置offer渠道token     *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setOfferChannelToken(String offerChannelToken) {
        this.offerChannelToken = offerChannelToken;
    }

}
