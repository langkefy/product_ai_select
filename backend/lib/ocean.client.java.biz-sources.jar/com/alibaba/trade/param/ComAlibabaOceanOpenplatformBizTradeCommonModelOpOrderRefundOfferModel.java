package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelOpOrderRefundOfferModel {

    private Long offerId;

    /**
     * @return 商品id
     */
    public Long getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    private String offerName;

    /**
     * @return 商品名称
     */
    public String getOfferName() {
        return offerName;
    }

    /**
     * 设置商品名称     *
     * 参数示例：<pre>测试商品</pre>     
     * 此参数必填
     */
    public void setOfferName(String offerName) {
        this.offerName = offerName;
    }

    private Long skuId;

    /**
     * @return skuId
     */
    public Long getSkuId() {
        return skuId;
    }

    /**
     * 设置skuId     *
     * 参数示例：<pre>456</pre>     
     * 此参数必填
     */
    public void setSkuId(Long skuId) {
        this.skuId = skuId;
    }

    private String skuName;

    /**
     * @return sku名称
     */
    public String getSkuName() {
        return skuName;
    }

    /**
     * 设置sku名称     *
     * 参数示例：<pre>测试: 测试1</pre>     
     * 此参数必填
     */
    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    private Long count;

    /**
     * @return 商品数量
     */
    public Long getCount() {
        return count;
    }

    /**
     * 设置商品数量     *
     * 参数示例：<pre>2</pre>     
     * 此参数必填
     */
    public void setCount(Long count) {
        this.count = count;
    }

    private String picUrl;

    /**
     * @return 商品图片
     */
    public String getPicUrl() {
        return picUrl;
    }

    /**
     * 设置商品图片     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    private Long price;

    /**
     * @return 商品单价（分）
     */
    public Long getPrice() {
        return price;
    }

    /**
     * 设置商品单价（分）     *
     * 参数示例：<pre>2</pre>     
     * 此参数必填
     */
    public void setPrice(Long price) {
        this.price = price;
    }

}
