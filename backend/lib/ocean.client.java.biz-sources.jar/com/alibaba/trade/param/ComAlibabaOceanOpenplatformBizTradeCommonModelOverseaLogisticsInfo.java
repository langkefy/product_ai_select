package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelOverseaLogisticsInfo {

    private ComAlibabaOceanOpenplatformBizCrossModelOverseasTransportUserAddrInfo overseasTransportUserAddrInfo;

    /**
     * @return 海外收货地址
     */
    public ComAlibabaOceanOpenplatformBizCrossModelOverseasTransportUserAddrInfo getOverseasTransportUserAddrInfo() {
        return overseasTransportUserAddrInfo;
    }

    /**
     * 设置海外收货地址     *
     * 参数示例：<pre>"addressDetail":"test", 						"cityName":"Г.Курчатов", 						"areaName":" ", 						"warehouseContactName":"Zeus", 						"mobile":"123456789", 						"fixedPhone":"123456789", 						"postCode":"1111", 						"provinceName":"Абайская область", 						"countryName":"Казахстан",</pre>     
     * 此参数必填
     */
    public void setOverseasTransportUserAddrInfo(ComAlibabaOceanOpenplatformBizCrossModelOverseasTransportUserAddrInfo overseasTransportUserAddrInfo) {
        this.overseasTransportUserAddrInfo = overseasTransportUserAddrInfo;
    }

    private String[] overseasLogisticsIds;

    /**
     * @return 海外物流单号
     */
    public String[] getOverseasLogisticsIds() {
        return overseasLogisticsIds;
    }

    /**
     * 设置海外物流单号     *
     * 参数示例：<pre>["TN0003077L" ]</pre>     
     * 此参数必填
     */
    public void setOverseasLogisticsIds(String[] overseasLogisticsIds) {
        this.overseasLogisticsIds = overseasLogisticsIds;
    }

}
