package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeResultTradeFeedbackResult {

    private String errorInfo;

    /**
     * @return 错误描述
     */
    public String getErrorInfo() {
        return errorInfo;
    }

    /**
     * 设置错误描述     *
     * 参数示例：<pre>错误描述</pre>     
     * 此参数必填
     */
    public void setErrorInfo(String errorInfo) {
        this.errorInfo = errorInfo;
    }

    private String errorCode;

    /**
     * @return 错误码
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * 设置错误码     *
     * 参数示例：<pre>400_1</pre>     
     * 此参数必填
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    private Boolean success;

    /**
     * @return 是否成功
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置是否成功     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

}
