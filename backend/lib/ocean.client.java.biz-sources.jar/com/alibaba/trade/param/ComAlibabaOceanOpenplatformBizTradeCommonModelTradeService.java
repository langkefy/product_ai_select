package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelTradeService {

    private String sourceType;

    /**
     * @return 源类型
     */
    public String getSourceType() {
        return sourceType;
    }

    /**
     * 设置源类型     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    private String serviceType;

    /**
     * @return 服务类型
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * 设置服务类型     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    private String sourceId;

    /**
     * @return 源id
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * 设置源id     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    private String title;

    /**
     * @return 名称
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置名称     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setTitle(String title) {
        this.title = title;
    }

    private Long unitPrice;

    /**
     * @return 单位价格
     */
    public Long getUnitPrice() {
        return unitPrice;
    }

    /**
     * 设置单位价格     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setUnitPrice(Long unitPrice) {
        this.unitPrice = unitPrice;
    }

    private Double quantity;

    /**
     * @return 数量
     */
    public Double getQuantity() {
        return quantity;
    }

    /**
     * 设置数量     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    private String serviceTips;

    /**
     * @return 服务tip
     */
    public String getServiceTips() {
        return serviceTips;
    }

    /**
     * 设置服务tip     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setServiceTips(String serviceTips) {
        this.serviceTips = serviceTips;
    }

    private String serviceUrl;

    /**
     * @return 服务url
     */
    public String getServiceUrl() {
        return serviceUrl;
    }

    /**
     * 设置服务url     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setServiceUrl(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }

    private String groupTitle;

    /**
     * @return 组名称
     */
    public String getGroupTitle() {
        return groupTitle;
    }

    /**
     * 设置组名称     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setGroupTitle(String groupTitle) {
        this.groupTitle = groupTitle;
    }

    private String groupCode;

    /**
     * @return 组code
     */
    public String getGroupCode() {
        return groupCode;
    }

    /**
     * 设置组code     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    private String sponsorDesc;

    /**
     * @return 描述
     */
    public String getSponsorDesc() {
        return sponsorDesc;
    }

    /**
     * 设置描述     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setSponsorDesc(String sponsorDesc) {
        this.sponsorDesc = sponsorDesc;
    }

    private String code;

    /**
     * @return code
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置code     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setCode(String code) {
        this.code = code;
    }

    private String extMapStr;

    /**
     * @return 扩展信息
     */
    public String getExtMapStr() {
        return extMapStr;
    }

    /**
     * 设置扩展信息     *
     * 参数示例：<pre>''</pre>     
     * 此参数必填
     */
    public void setExtMapStr(String extMapStr) {
        this.extMapStr = extMapStr;
    }

}
