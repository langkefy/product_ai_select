package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeParamTradeFeedbackParam {

    private String feedback;

    /**
     * @return 留言
     */
    public String getFeedback() {
        return feedback;
    }

    /**
     * 设置留言     *
     * 参数示例：<pre>留言</pre>     
     * 此参数必填
     */
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    private String orderId;

    /**
     * @return 订单ID
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * 设置订单ID     *
     * 参数示例：<pre>12344444555545</pre>     
     * 此参数必填
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

}
