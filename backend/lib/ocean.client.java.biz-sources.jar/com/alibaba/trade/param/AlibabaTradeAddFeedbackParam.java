package com.alibaba.trade.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeAddFeedbackParam extends AbstractAPIRequest<AlibabaTradeAddFeedbackResult> {

    public AlibabaTradeAddFeedbackParam() {
        super();
        oceanApiId = new APIId("com.alibaba.trade", "alibaba.trade.addFeedback", 1);
    }

    private AlibabaOceanOpenplatformBizTradeParamTradeFeedbackParam tradeFeedbackParam;

    /**
     * @return 请求参数
     */
    public AlibabaOceanOpenplatformBizTradeParamTradeFeedbackParam getTradeFeedbackParam() {
        return tradeFeedbackParam;
    }

    /**
     * 设置请求参数     *
     * 参数示例：<pre>{"feedback":"test","orderId":"123123213"}</pre>     
     * 此参数必填
     */
    public void setTradeFeedbackParam(AlibabaOceanOpenplatformBizTradeParamTradeFeedbackParam tradeFeedbackParam) {
        this.tradeFeedbackParam = tradeFeedbackParam;
    }

}
