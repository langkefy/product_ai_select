package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaCreateOrderPreviewResultModel {

    private Long discountFee;

    /**
     * @return 计算完货品金额后再次进行的减免金额. 单位: 分
     */
    public Long getDiscountFee() {
        return discountFee;
    }

    /**
     * 设置计算完货品金额后再次进行的减免金额. 单位: 分     *
     * 参数示例：<pre>'' </pre>     
     * 此参数必填
     */
    public void setDiscountFee(Long discountFee) {
        this.discountFee = discountFee;
    }

    private String[] tradeModeNameList;

    /**
     * @return 当前交易在使用下单接口时可以支持的交易方式列表，其中的元素可以直接用于下单接口的tradeType入参。列表为空，当前交易不可通过接口下单，需要在1688页面下单。
     */
    public String[] getTradeModeNameList() {
        return tradeModeNameList;
    }

    /**
     * 设置当前交易在使用下单接口时可以支持的交易方式列表，其中的元素可以直接用于下单接口的tradeType入参。列表为空，当前交易不可通过接口下单，需要在1688页面下单。     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setTradeModeNameList(String[] tradeModeNameList) {
        this.tradeModeNameList = tradeModeNameList;
    }

    private Boolean status;

    /**
     * @return 状态
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * 设置状态     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }

    private Boolean taoSampleSinglePromotion;

    /**
     * @return 是否有淘货源单品优惠  false:有单品优惠   true：没有单品优惠
     */
    public Boolean getTaoSampleSinglePromotion() {
        return taoSampleSinglePromotion;
    }

    /**
     * 设置是否有淘货源单品优惠  false:有单品优惠   true：没有单品优惠     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setTaoSampleSinglePromotion(Boolean taoSampleSinglePromotion) {
        this.taoSampleSinglePromotion = taoSampleSinglePromotion;
    }

    private Long sumPayment;

    /**
     * @return 订单总费用, 单位为分.
     */
    public Long getSumPayment() {
        return sumPayment;
    }

    /**
     * 设置订单总费用, 单位为分.     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setSumPayment(Long sumPayment) {
        this.sumPayment = sumPayment;
    }

    private String message;

    /**
     * @return 返回信息
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置返回信息     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setMessage(String message) {
        this.message = message;
    }

    private Long sumCarriage;

    /**
     * @return 总运费信息, 单位为分.
     */
    public Long getSumCarriage() {
        return sumCarriage;
    }

    /**
     * 设置总运费信息, 单位为分.     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setSumCarriage(Long sumCarriage) {
        this.sumCarriage = sumCarriage;
    }

    private String resultCode;

    /**
     * @return 返回码
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * 设置返回码     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    private Long sumPaymentNoCarriage;

    /**
     * @return 不包含运费的货品总费用, 单位为分.
     */
    public Long getSumPaymentNoCarriage() {
        return sumPaymentNoCarriage;
    }

    /**
     * 设置不包含运费的货品总费用, 单位为分.     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setSumPaymentNoCarriage(Long sumPaymentNoCarriage) {
        this.sumPaymentNoCarriage = sumPaymentNoCarriage;
    }

    private Long additionalFee;

    /**
     * @return 附加费,单位，分
     */
    public Long getAdditionalFee() {
        return additionalFee;
    }

    /**
     * 设置附加费,单位，分     *
     * 参数示例：<pre>''  </pre>     
     * 此参数必填
     */
    public void setAdditionalFee(Long additionalFee) {
        this.additionalFee = additionalFee;
    }

    private String flowFlag;

    /**
     * @return 订单下单流程
     */
    public String getFlowFlag() {
        return flowFlag;
    }

    /**
     * 设置订单下单流程     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setFlowFlag(String flowFlag) {
        this.flowFlag = flowFlag;
    }

    private AlibabaCreateOrderPreviewResultCargoModel[] cargoList;

    /**
     * @return 规格信息
     */
    public AlibabaCreateOrderPreviewResultCargoModel[] getCargoList() {
        return cargoList;
    }

    /**
     * 设置规格信息     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setCargoList(AlibabaCreateOrderPreviewResultCargoModel[] cargoList) {
        this.cargoList = cargoList;
    }

    private AlibabaTradePromotionModel[] shopPromotionList;

    /**
     * @return 可用店铺级别优惠列表
     */
    public AlibabaTradePromotionModel[] getShopPromotionList() {
        return shopPromotionList;
    }

    /**
     * 设置可用店铺级别优惠列表     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setShopPromotionList(AlibabaTradePromotionModel[] shopPromotionList) {
        this.shopPromotionList = shopPromotionList;
    }

    private TradeModelExtensionList[] tradeModelList;

    /**
     * @return 当前交易可以支持的交易方式列表。结果可以参照1688下单预览页面的交易方式。
     */
    public TradeModelExtensionList[] getTradeModelList() {
        return tradeModelList;
    }

    /**
     * 设置当前交易可以支持的交易方式列表。结果可以参照1688下单预览页面的交易方式。     *
     * 参数示例：<pre> '' </pre>     
     * 此参数必填
     */
    public void setTradeModelList(TradeModelExtensionList[] tradeModelList) {
        this.tradeModelList = tradeModelList;
    }

    private PayChaneelList[] payChannelInfos;

    /**
     * @return 当前交易支持的支付渠道信息
     */
    public PayChaneelList[] getPayChannelInfos() {
        return payChannelInfos;
    }

    /**
     * 设置当前交易支持的支付渠道信息     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setPayChannelInfos(PayChaneelList[] payChannelInfos) {
        this.payChannelInfos = payChannelInfos;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelTradeServiceGroup[] tradeServiceList;

    /**
     * @return 提供的服务列表，比如跨境物流服务等
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelTradeServiceGroup[] getTradeServiceList() {
        return tradeServiceList;
    }

    /**
     * 设置提供的服务列表，比如跨境物流服务等     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setTradeServiceList(ComAlibabaOceanOpenplatformBizTradeCommonModelTradeServiceGroup[] tradeServiceList) {
        this.tradeServiceList = tradeServiceList;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] extPairList;

    /**
     * @return 扩展对象列表
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] getExtPairList() {
        return extPairList;
    }

    /**
     * 设置扩展对象列表     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setExtPairList(ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair[] extPairList) {
        this.extPairList = extPairList;
    }

    private Boolean canUseOfficialSolution;

    /**
     * @return 是否可用官方物流提货
     */
    public Boolean getCanUseOfficialSolution() {
        return canUseOfficialSolution;
    }

    /**
     * 设置是否可用官方物流提货     *
     * 参数示例：<pre>true</pre>     
     * 此参数必填
     */
    public void setCanUseOfficialSolution(Boolean canUseOfficialSolution) {
        this.canUseOfficialSolution = canUseOfficialSolution;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel officialSolutionModel;

    /**
     * @return 官方物流提货服务
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel getOfficialSolutionModel() {
        return officialSolutionModel;
    }

    /**
     * 设置官方物流提货服务     *
     * 参数示例：<pre>{           "cheaperAmount": 0,           "originalDeliveryCost": 1832,           "solutionCode": "471",           "solutionName": "特惠当日上门",           "totalCost": 770         }</pre>     
     * 此参数必填
     */
    public void setOfficialSolutionModel(ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel officialSolutionModel) {
        this.officialSolutionModel = officialSolutionModel;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel[] officialSolutionModelList;

    /**
     * @return 官方物流提货服务列表
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel[] getOfficialSolutionModelList() {
        return officialSolutionModelList;
    }

    /**
     * 设置官方物流提货服务列表     *
     * 参数示例：<pre>[{"solutionCode":"471","solutionName":"特惠当日上门","totalCost":770}]</pre>     
     * 此参数必填
     */
    public void setOfficialSolutionModelList(ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel[] officialSolutionModelList) {
        this.officialSolutionModelList = officialSolutionModelList;
    }

    private String orderGroup;

    /**
     * @return 订单分组group，指定官方物流提货方案时，需要按该字段分组指定
     */
    public String getOrderGroup() {
        return orderGroup;
    }

    /**
     * 设置订单分组group，指定官方物流提货方案时，需要按该字段分组指定     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOrderGroup(String orderGroup) {
        this.orderGroup = orderGroup;
    }

}
