package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizCrossModelOverseasTransportUserAddrInfo {

    private String postCode;

    /**
     * @return 物流码
     */
    public String getPostCode() {
        return postCode;
    }

    /**
     * 设置物流码     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    private String countryName;

    /**
     * @return 国家
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * 设置国家     *
     * 参数示例：<pre>越南</pre>     
     * 此参数必填
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    private String provinceName;

    /**
     * @return 省份
     */
    public String getProvinceName() {
        return provinceName;
    }

    /**
     * 设置省份     *
     * 参数示例：<pre>xx</pre>     
     * 此参数必填
     */
    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    private String cityName;

    /**
     * @return 城市
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 设置城市     *
     * 参数示例：<pre>x x</pre>     
     * 此参数必填
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    private String areaName;

    /**
     * @return 区
     */
    public String getAreaName() {
        return areaName;
    }

    /**
     * 设置区     *
     * 参数示例：<pre>xx</pre>     
     * 此参数必填
     */
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    private String addressDetail;

    /**
     * @return 地址
     */
    public String getAddressDetail() {
        return addressDetail;
    }

    /**
     * 设置地址     *
     * 参数示例：<pre>xx</pre>     
     * 此参数必填
     */
    public void setAddressDetail(String addressDetail) {
        this.addressDetail = addressDetail;
    }

    private String mobile;

    /**
     * @return 手机号
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 设置手机号     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    private String fixedPhone;

    /**
     * @return 手机号
     */
    public String getFixedPhone() {
        return fixedPhone;
    }

    /**
     * 设置手机号     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setFixedPhone(String fixedPhone) {
        this.fixedPhone = fixedPhone;
    }

    private String warehouseContactName;

    /**
     * @return 仓库联系人
     */
    public String getWarehouseContactName() {
        return warehouseContactName;
    }

    /**
     * 设置仓库联系人     *
     * 参数示例：<pre>aa</pre>     
     * 此参数必填
     */
    public void setWarehouseContactName(String warehouseContactName) {
        this.warehouseContactName = warehouseContactName;
    }

    private String warehouseName;

    /**
     * @return 仓库名称
     */
    public String getWarehouseName() {
        return warehouseName;
    }

    /**
     * 设置仓库名称     *
     * 参数示例：<pre>aa</pre>     
     * 此参数必填
     */
    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }

}
