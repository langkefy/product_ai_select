package com.alibaba.trade.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaAlipayUrlGetParam extends AbstractAPIRequest<AlibabaAlipayUrlGetResult> {

    public AlibabaAlipayUrlGetParam() {
        super();
        oceanApiId = new APIId("com.alibaba.trade", "alibaba.alipay.url.get", 1);
    }

    private long[] orderIdList;

    /**
     * @return 订单Id列表,最多批量100个订单，跨境宝批量最大只支持30笔。
     */
    public long[] getOrderIdList() {
        return orderIdList;
    }

    /**
     * 设置订单Id列表,最多批量100个订单，跨境宝批量最大只支持30笔。     *
     * 参数示例：<pre>[74321349391498520]</pre>     
     * 此参数必填
     */
    public void setOrderIdList(long[] orderIdList) {
        this.orderIdList = orderIdList;
    }

}
