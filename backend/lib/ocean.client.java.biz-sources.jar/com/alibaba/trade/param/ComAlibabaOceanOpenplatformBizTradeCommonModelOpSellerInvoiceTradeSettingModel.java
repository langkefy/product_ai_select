package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelOpSellerInvoiceTradeSettingModel {

    private String tradeInvoiceStatus;

    /**
     * @return 交易开票状态，-1:不可开票；0-允许开票；1-已申请；2-已开票
     */
    public String getTradeInvoiceStatus() {
        return tradeInvoiceStatus;
    }

    /**
     * 设置交易开票状态，-1:不可开票；0-允许开票；1-已申请；2-已开票     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setTradeInvoiceStatus(String tradeInvoiceStatus) {
        this.tradeInvoiceStatus = tradeInvoiceStatus;
    }

    private String sellerInvoiceType;

    /**
     * @return 开票类型，0-普票；1专票；2-普票/专票
     */
    public String getSellerInvoiceType() {
        return sellerInvoiceType;
    }

    /**
     * 设置开票类型，0-普票；1专票；2-普票/专票     *
     * 参数示例：<pre>0</pre>     
     * 此参数必填
     */
    public void setSellerInvoiceType(String sellerInvoiceType) {
        this.sellerInvoiceType = sellerInvoiceType;
    }

}
