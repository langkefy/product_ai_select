package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelExtrPair {

    private String key;

    /**
     * @return 键
     */
    public String getKey() {
        return key;
    }

    /**
     * 设置键     *
     * 参数示例：<pre>doorPickup</pre>     
     * 此参数必填
     */
    public void setKey(String key) {
        this.key = key;
    }

    private String value;

    /**
     * @return 值
     */
    public String getValue() {
        return value;
    }

    /**
     * 设置值     *
     * 参数示例：<pre>{       "serviceCode": "mkd",       "price": 1200, // 人民币，分     }</pre>     
     * 此参数必填
     */
    public void setValue(String value) {
        this.value = value;
    }

    private String desc;

    /**
     * @return 描述
     */
    public String getDesc() {
        return desc;
    }

    /**
     * 设置描述     *
     * 参数示例：<pre>是否使用上门揽</pre>     
     * 此参数必填
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

}
