package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeParamOpMaxRefundFeeGetParam {

    private String goodsStatus;

    /**
     * @return 货物状态	
     */
    public String getGoodsStatus() {
        return goodsStatus;
    }

    /**
     * 设置货物状态	     *
     * 参数示例：<pre> 售中等待卖家发货:"refundWaitSellerSend"; 售中等待买家收货:"refundWaitBuyerReceive"; 售中已收货（未确认完成交易）:"refundBuyerReceived" 售后未收货:"aftersaleBuyerNotReceived"; 售后已收到货:"aftersaleBuyerReceived"</pre>     
     * 此参数必填
     */
    public void setGoodsStatus(String goodsStatus) {
        this.goodsStatus = goodsStatus;
    }

    private Long orderId;

    /**
     * @return 订单ID
     */
    public Long getOrderId() {
        return orderId;
    }

    /**
     * 设置订单ID     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    private String refundId;

    /**
     * @return 退款单必须处于退款中，可不传
     */
    public String getRefundId() {
        return refundId;
    }

    /**
     * 设置退款单必须处于退款中，可不传     *
     * 参数示例：<pre>TQ123</pre>     
     * 此参数必填
     */
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    private AlibabaOceanOpenplatformBizTradeCommonModelOrderEntryCountModel[] refundGoodsCountList;

    /**
     * @return 退货数量
     */
    public AlibabaOceanOpenplatformBizTradeCommonModelOrderEntryCountModel[] getRefundGoodsCountList() {
        return refundGoodsCountList;
    }

    /**
     * 设置退货数量     *
     * 参数示例：<pre>[{1: 1}]</pre>     
     * 此参数必填
     */
    public void setRefundGoodsCountList(AlibabaOceanOpenplatformBizTradeCommonModelOrderEntryCountModel[] refundGoodsCountList) {
        this.refundGoodsCountList = refundGoodsCountList;
    }

}
