package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeRefundOpQueryBatchRefundByOrderIdAndStatusResultModel {

    private AlibabaTradeRefundOpOrderRefundModel[] opOrderRefundModels;

    /**
     * @return 退款单信息
     */
    public AlibabaTradeRefundOpOrderRefundModel[] getOpOrderRefundModels() {
        return opOrderRefundModels;
    }

    /**
     * 设置退款单信息     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setOpOrderRefundModels(AlibabaTradeRefundOpOrderRefundModel[] opOrderRefundModels) {
        this.opOrderRefundModels = opOrderRefundModels;
    }

}
