package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeParamCrossBorderLogisticsSelfPickupAddress {

    private String addressText;

    /**
     * @return 集运仓自提地址，不用填写省市区，省市区跟默认解决方案集运仓一致
     */
    public String getAddressText() {
        return addressText;
    }

    /**
     * 设置集运仓自提地址，不用填写省市区，省市区跟默认解决方案集运仓一致     *
     * 参数示例：<pre>网商路699号</pre>     
     * 此参数必填
     */
    public void setAddressText(String addressText) {
        this.addressText = addressText;
    }

    private String mobile;

    /**
     * @return 集运仓自提手机号
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 设置集运仓自提手机号     *
     * 参数示例：<pre>18792983782</pre>     
     * 此参数必填
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    private String contractName;

    /**
     * @return 集运仓自提联系人
     */
    public String getContractName() {
        return contractName;
    }

    /**
     * 设置集运仓自提联系人     *
     * 参数示例：<pre>无名</pre>     
     * 此参数必填
     */
    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

}
