package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeResultOrderRefundCreateResult {

    private String refundId;

    /**
     * @return 创建成功，退款id
     */
    public String getRefundId() {
        return refundId;
    }

    /**
     * 设置创建成功，退款id     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    private Long innerReasonId;

    /**
     * @return 1688退款原因ID
     */
    public Long getInnerReasonId() {
        return innerReasonId;
    }

    /**
     * 设置1688退款原因ID     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setInnerReasonId(Long innerReasonId) {
        this.innerReasonId = innerReasonId;
    }

    private String innerReason;

    /**
     * @return 1688退款原因
     */
    public String getInnerReason() {
        return innerReason;
    }

    /**
     * 设置1688退款原因     *
     * 参数示例：<pre>不</pre>     
     * 此参数必填
     */
    public void setInnerReason(String innerReason) {
        this.innerReason = innerReason;
    }

    private Long innerPostFee;

    /**
     * @return 转换后退运费金额（分）
     */
    public Long getInnerPostFee() {
        return innerPostFee;
    }

    /**
     * 设置转换后退运费金额（分）     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setInnerPostFee(Long innerPostFee) {
        this.innerPostFee = innerPostFee;
    }

    private String isVoucher;

    /**
     * @return 是否写入留言凭证 1-是 0-否
     */
    public String getIsVoucher() {
        return isVoucher;
    }

    /**
     * 设置是否写入留言凭证 1-是 0-否     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setIsVoucher(String isVoucher) {
        this.isVoucher = isVoucher;
    }

    private Long refundOfficialSolutionCost;

    /**
     * @return 退官方物流提货订单费用（分）
     */
    public Long getRefundOfficialSolutionCost() {
        return refundOfficialSolutionCost;
    }

    /**
     * 设置退官方物流提货订单费用（分）     *
     * 参数示例：<pre>770</pre>     
     * 此参数必填
     */
    public void setRefundOfficialSolutionCost(Long refundOfficialSolutionCost) {
        this.refundOfficialSolutionCost = refundOfficialSolutionCost;
    }

}
