package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformCommonOpMaxRefundFeeResultModel {

    private String code;

    /**
     * @return  
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setCode(String code) {
        this.code = code;
    }

    private String message;

    /**
     * @return  
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setMessage(String message) {
        this.message = message;
    }

    private AlibabaOceanOpenplatformBizTradeCommonModelOpMaxRefundFeeModel result;

    /**
     * @return   
     */
    public AlibabaOceanOpenplatformBizTradeCommonModelOpMaxRefundFeeModel getResult() {
        return result;
    }

    /**
     * 设置       *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setResult(AlibabaOceanOpenplatformBizTradeCommonModelOpMaxRefundFeeModel result) {
        this.result = result;
    }

    private String[] retCodes;

    /**
     * @return  
     */
    public String[] getRetCodes() {
        return retCodes;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setRetCodes(String[] retCodes) {
        this.retCodes = retCodes;
    }

    private String subCode;

    /**
     * @return  
     */
    public String getSubCode() {
        return subCode;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    private String subMessage;

    /**
     * @return  
     */
    public String getSubMessage() {
        return subMessage;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setSubMessage(String subMessage) {
        this.subMessage = subMessage;
    }

    private Boolean success;

    /**
     * @return  
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置      *
     * 参数示例：<pre> </pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

}
