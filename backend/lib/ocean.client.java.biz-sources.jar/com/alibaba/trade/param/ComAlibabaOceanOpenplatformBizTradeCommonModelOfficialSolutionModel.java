package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizTradeCommonModelOfficialSolutionModel {

    private String solutionCode;

    /**
     * @return 物流解决方案编码
     */
    public String getSolutionCode() {
        return solutionCode;
    }

    /**
     * 设置物流解决方案编码     *
     * 参数示例：<pre>471</pre>     
     * 此参数必填
     */
    public void setSolutionCode(String solutionCode) {
        this.solutionCode = solutionCode;
    }

    private String solutionName;

    /**
     * @return 物流解决方案名称
     */
    public String getSolutionName() {
        return solutionName;
    }

    /**
     * 设置物流解决方案名称     *
     * 参数示例：<pre>特惠当日上门</pre>     
     * 此参数必填
     */
    public void setSolutionName(String solutionName) {
        this.solutionName = solutionName;
    }

    private Long totalCost;

    /**
     * @return 总费用
     */
    public Long getTotalCost() {
        return totalCost;
    }

    /**
     * 设置总费用     *
     * 参数示例：<pre>770</pre>     
     * 此参数必填
     */
    public void setTotalCost(Long totalCost) {
        this.totalCost = totalCost;
    }

}
