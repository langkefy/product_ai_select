package com.alibaba.trade.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaTradeFastCreateOrderParam extends AbstractAPIRequest<AlibabaTradeFastCreateOrderResult> {

    public AlibabaTradeFastCreateOrderParam() {
        super();
        oceanApiId = new APIId("com.alibaba.trade", "alibaba.trade.fastCreateOrder", 1);
    }

    private String flow;

    /**
     * @return general（创建大市场订单），fenxiao（创建分销订单）,saleproxy流程将校验分销关系,paired(火拼下单),boutiquefenxiao(精选货源分销价下单，采购量1个使用包邮)， boutiquepifa(精选货源批发价下单，采购量大于2使用).
     */
    public String getFlow() {
        return flow;
    }

    /**
     * 设置general（创建大市场订单），fenxiao（创建分销订单）,saleproxy流程将校验分销关系,paired(火拼下单),boutiquefenxiao(精选货源分销价下单，采购量1个使用包邮)， boutiquepifa(精选货源批发价下单，采购量大于2使用).     *
     * 参数示例：<pre>general</pre>     
     * 此参数必填
     */
    public void setFlow(String flow) {
        this.flow = flow;
    }

    private Long subUserId;

    /**
     * @return 子账号ID
     */
    public Long getSubUserId() {
        return subUserId;
    }

    /**
     * 设置子账号ID     *
     * 参数示例：<pre>222222</pre>     
     * 此参数必填
     */
    public void setSubUserId(Long subUserId) {
        this.subUserId = subUserId;
    }

    private String message;

    /**
     * @return 买家留言
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置买家留言     *
     * 参数示例：<pre>留言</pre>     
     * 此参数必填
     */
    public void setMessage(String message) {
        this.message = message;
    }

    private AlibabaTradeFastAddress addressParam;

    /**
     * @return 收货地址信息
     */
    public AlibabaTradeFastAddress getAddressParam() {
        return addressParam;
    }

    /**
     * 设置收货地址信息     *
     * 参数示例：<pre>{"address":"网商路699号","phone": "0517-88990077","mobile": "15251667788","fullName": "张三","postCode": "000000","areaText": "滨江区","townText": "","cityText": "杭州市","provinceText": "浙江省"}</pre>     
     * 此参数必填
     */
    public void setAddressParam(AlibabaTradeFastAddress addressParam) {
        this.addressParam = addressParam;
    }

    private AlibabaTradeFastCargo[] cargoParamList;

    /**
     * @return 商品信息
     */
    public AlibabaTradeFastCargo[] getCargoParamList() {
        return cargoParamList;
    }

    /**
     * 设置商品信息     *
     * 参数示例：<pre>[{"specId": "b266e0726506185beaf205cbae88530d","quantity": 5,"offerId": 554456348334},{"specId": "2ba3d63866a71fbae83909d9b4814f01","quantity": 6,"offerId": 554456348334}]</pre>     
     * 此参数必填
     */
    public void setCargoParamList(AlibabaTradeFastCargo[] cargoParamList) {
        this.cargoParamList = cargoParamList;
    }

    private AlibabaTradeFastInvoice invoiceParam;

    /**
     * @return 发票信息
     */
    public AlibabaTradeFastInvoice getInvoiceParam() {
        return invoiceParam;
    }

    /**
     * 设置发票信息     *
     * 参数示例：<pre>{"invoiceType":0,"cityText": "杭州市","provinceText": "浙江省","address": "网商路699号","phone": "0517-88990077","mobile": "15251667788","fullName": "张五","postCode": "000000","areaText": "滨江区","companyName": "测试公司","taxpayerIdentifier": "123455"}</pre>     
     * 此参数必填
     */
    public void setInvoiceParam(AlibabaTradeFastInvoice invoiceParam) {
        this.invoiceParam = invoiceParam;
    }

    private String isvBizTypeStr;

    /**
     * @return 开放平台业务码,区分具体业务,isv_fxgl等
     */
    public String getIsvBizTypeStr() {
        return isvBizTypeStr;
    }

    /**
     * 设置开放平台业务码,区分具体业务,isv_fxgl等     *
     * 参数示例：<pre>请咨询运营，不同解决方案使用不同业务码</pre>     
     * 此参数必填
     */
    public void setIsvBizTypeStr(String isvBizTypeStr) {
        this.isvBizTypeStr = isvBizTypeStr;
    }

    private Boolean isvBizTypeErp;

    /**
     * @return erp分销场景时传入true。会修改默认的isvBizType为erp_buy。其他场景不用传入
     */
    public Boolean getIsvBizTypeErp() {
        return isvBizTypeErp;
    }

    /**
     * 设置erp分销场景时传入true。会修改默认的isvBizType为erp_buy。其他场景不用传入     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setIsvBizTypeErp(Boolean isvBizTypeErp) {
        this.isvBizTypeErp = isvBizTypeErp;
    }

    private Boolean isvBizTypePD;

    /**
     * @return 拍单场景时传入true。会修改默认的isvBizTyp为isv_pd_buy
     */
    public Boolean getIsvBizTypePD() {
        return isvBizTypePD;
    }

    /**
     * 设置拍单场景时传入true。会修改默认的isvBizTyp为isv_pd_buy     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setIsvBizTypePD(Boolean isvBizTypePD) {
        this.isvBizTypePD = isvBizTypePD;
    }

    private String shopPromotionId;

    /**
     * @return 店铺优惠ID，通过“创建订单前预览数据接口”获得。为空默认使用默认优惠
     */
    public String getShopPromotionId() {
        return shopPromotionId;
    }

    /**
     * 设置店铺优惠ID，通过“创建订单前预览数据接口”获得。为空默认使用默认优惠     *
     * 参数示例：<pre>itemCoupon-5600812521_31032085284-398517001570</pre>     
     * 此参数必填
     */
    public void setShopPromotionId(String shopPromotionId) {
        this.shopPromotionId = shopPromotionId;
    }

    private String tradeType;

    /**
     * @return 由于不同的商品支持的交易方式不同，没有一种交易方式是全局通用的，所以当前下单可使用的交易方式必须通过下单预览接口的tradeModeNameList获取。交易方式类型说明：assureTrade（交易4.0通用担保交易），alipay（大市场通用的支付宝担保交易（目前在做切流，后续会下掉）），period（普通账期交易）, assure（大买家企业采购询报价下单时需要使用的担保交易流程）, creditBuy（诚E赊），bank（银行转账），631staged（631分阶段付款），37staged（37分阶段）；此字段不传则系统默认会选取一个可用的交易方式下单，如果开通了诚E赊默认是creditBuy（诚E赊），未开通诚E赊默认使用的方式是支付宝担宝交易。
     */
    public String getTradeType() {
        return tradeType;
    }

    /**
     * 设置由于不同的商品支持的交易方式不同，没有一种交易方式是全局通用的，所以当前下单可使用的交易方式必须通过下单预览接口的tradeModeNameList获取。交易方式类型说明：assureTrade（交易4.0通用担保交易），alipay（大市场通用的支付宝担保交易（目前在做切流，后续会下掉）），period（普通账期交易）, assure（大买家企业采购询报价下单时需要使用的担保交易流程）, creditBuy（诚E赊），bank（银行转账），631staged（631分阶段付款），37staged（37分阶段）；此字段不传则系统默认会选取一个可用的交易方式下单，如果开通了诚E赊默认是creditBuy（诚E赊），未开通诚E赊默认使用的方式是支付宝担宝交易。     *
     * 参数示例：<pre>assureTrade</pre>     
     * 此参数必填
     */
    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    private AlibabaTradeFastCreateOrderEncryptOutOrderInfo encryptOutOrderInfo;

    /**
     * @return 下游加密订单信息，用于下游平台打单使用。如果下游明文，encryptOrder传入false
     */
    public AlibabaTradeFastCreateOrderEncryptOutOrderInfo getEncryptOutOrderInfo() {
        return encryptOutOrderInfo;
    }

    /**
     * 设置下游加密订单信息，用于下游平台打单使用。如果下游明文，encryptOrder传入false     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setEncryptOutOrderInfo(AlibabaTradeFastCreateOrderEncryptOutOrderInfo encryptOutOrderInfo) {
        this.encryptOutOrderInfo = encryptOutOrderInfo;
    }

    private String instanceId;

    /**
     * @return 批发团instanceId,从alibaba.pifatuan.product.list获取
     */
    public String getInstanceId() {
        return instanceId;
    }

    /**
     * 设置批发团instanceId,从alibaba.pifatuan.product.list获取     *
     * 参数示例：<pre>4063139_1662080400000</pre>     
     * 此参数必填
     */
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    private String proxySettleRecordId;

    /**
     * @return 分账普通下单采购单id，交易flow为“proxy”
     */
    public String getProxySettleRecordId() {
        return proxySettleRecordId;
    }

    /**
     * 设置分账普通下单采购单id，交易flow为“proxy”     *
     * 参数示例：<pre>4051300002</pre>     
     * 此参数必填
     */
    public void setProxySettleRecordId(String proxySettleRecordId) {
        this.proxySettleRecordId = proxySettleRecordId;
    }

    private String fenxiaoChannel;

    /**
     * @return 回流订单下游平台 淘宝-thyny，天猫-tm，淘特-taote，阿里巴巴C2M-c2m，京东-jingdong，拼多多-pinduoduo，微信小店-weixin，跨境-kuajing，快手-kuaishou，有赞-youzan，抖音-douyin，寺库-siku，美团团好货-meituan，小红书-xiaohongshu，当当-dangdang，苏宁-suning，大V店-davdian，行云-xingyun，蜜芽-miya，菠萝派商城-boluo，快团团-kuaituantuan，其他-other
     */
    public String getFenxiaoChannel() {
        return fenxiaoChannel;
    }

    /**
     * 设置回流订单下游平台 淘宝-thyny，天猫-tm，淘特-taote，阿里巴巴C2M-c2m，京东-jingdong，拼多多-pinduoduo，微信小店-weixin，跨境-kuajing，快手-kuaishou，有赞-youzan，抖音-douyin，寺库-siku，美团团好货-meituan，小红书-xiaohongshu，当当-dangdang，苏宁-suning，大V店-davdian，行云-xingyun，蜜芽-miya，菠萝派商城-boluo，快团团-kuaituantuan，其他-other     *
     * 参数示例：<pre>douyin</pre>     
     * 此参数必填
     */
    public void setFenxiaoChannel(String fenxiaoChannel) {
        this.fenxiaoChannel = fenxiaoChannel;
    }

    private String outOrderId;

    /**
     * @return 外部订单号,可用于幂等。通过订单列表接口可以传入该值查询订单信息
     */
    public String getOutOrderId() {
        return outOrderId;
    }

    /**
     * 设置外部订单号,可用于幂等。通过订单列表接口可以传入该值查询订单信息     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOutOrderId(String outOrderId) {
        this.outOrderId = outOrderId;
    }

    private String preSelectPayChannel;

    /**
     * @return 预选的支付渠道，用作财务订单分流。订单信息查询接口返回：result.exAttributes.preSelectPayChannel ，该值是创建订单接口时传入的预选的支付渠道标记。
     */
    public String getPreSelectPayChannel() {
        return preSelectPayChannel;
    }

    /**
     * 设置预选的支付渠道，用作财务订单分流。订单信息查询接口返回：result.exAttributes.preSelectPayChannel ，该值是创建订单接口时传入的预选的支付渠道标记。     *
     * 参数示例：<pre>alipay</pre>     
     * 此参数必填
     */
    public void setPreSelectPayChannel(String preSelectPayChannel) {
        this.preSelectPayChannel = preSelectPayChannel;
    }

    private Boolean noUseRedEnvelope;

    /**
     * @return 弃用
     */
    public Boolean getNoUseRedEnvelope() {
        return noUseRedEnvelope;
    }

    /**
     * 设置弃用     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setNoUseRedEnvelope(Boolean noUseRedEnvelope) {
        this.noUseRedEnvelope = noUseRedEnvelope;
    }

    private String useRedEnvelope;

    /**
     * @return 使用红包：n不使用，y使用。默认使用红包
     */
    public String getUseRedEnvelope() {
        return useRedEnvelope;
    }

    /**
     * 设置使用红包：n不使用，y使用。默认使用红包     *
     * 参数示例：<pre>n</pre>     
     * 此参数必填
     */
    public void setUseRedEnvelope(String useRedEnvelope) {
        this.useRedEnvelope = useRedEnvelope;
    }

    private ComAlibabaOceanOpenplatformBizTradeParamExtendParam extendParam;

    /**
     * @return 订单拓展参数
     */
    public ComAlibabaOceanOpenplatformBizTradeParamExtendParam getExtendParam() {
        return extendParam;
    }

    /**
     * 设置订单拓展参数     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setExtendParam(ComAlibabaOceanOpenplatformBizTradeParamExtendParam extendParam) {
        this.extendParam = extendParam;
    }

    private Boolean useOfficialSolution;

    /**
     * @return 配送方式使用官方物流提货
     */
    public Boolean getUseOfficialSolution() {
        return useOfficialSolution;
    }

    /**
     * 设置配送方式使用官方物流提货     *
     * 参数示例：<pre>false</pre>     
     * 此参数必填
     */
    public void setUseOfficialSolution(Boolean useOfficialSolution) {
        this.useOfficialSolution = useOfficialSolution;
    }

    private ComAlibabaOceanOpenplatformBizTradeCommonModelUseOfficialSolutionModel[] useOfficialSolutionModelList;

    /**
     * @return 官方物流提货物流解决方案（useOfficialSolution为true时必填）
     */
    public ComAlibabaOceanOpenplatformBizTradeCommonModelUseOfficialSolutionModel[] getUseOfficialSolutionModelList() {
        return useOfficialSolutionModelList;
    }

    /**
     * 设置官方物流提货物流解决方案（useOfficialSolution为true时必填）     *
     * 参数示例：<pre>[]</pre>     
     * 此参数必填
     */
    public void setUseOfficialSolutionModelList(ComAlibabaOceanOpenplatformBizTradeCommonModelUseOfficialSolutionModel[] useOfficialSolutionModelList) {
        this.useOfficialSolutionModelList = useOfficialSolutionModelList;
    }

}
