package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeResultBizSimpleOrder {

    private Boolean success;

    /**
     * @return 
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    private String message;

    /**
     * @return 
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setMessage(String message) {
        this.message = message;
    }

    private String resultCode;

    /**
     * @return 
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    private String orderId;

    /**
     * @return 
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    private Long orderAmmount;

    /**
     * @return 
     */
    public Long getOrderAmmount() {
        return orderAmmount;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setOrderAmmount(Long orderAmmount) {
        this.orderAmmount = orderAmmount;
    }

    private Boolean mergePay;

    /**
     * @return 
     */
    public Boolean getMergePay() {
        return mergePay;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setMergePay(Boolean mergePay) {
        this.mergePay = mergePay;
    }

    private String payChannel;

    /**
     * @return 
     */
    public String getPayChannel() {
        return payChannel;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPayChannel(String payChannel) {
        this.payChannel = payChannel;
    }

    private Long postFee;

    /**
     * @return 
     */
    public Long getPostFee() {
        return postFee;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPostFee(Long postFee) {
        this.postFee = postFee;
    }

    private Long discount;

    /**
     * @return 
     */
    public Long getDiscount() {
        return discount;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setDiscount(Long discount) {
        this.discount = discount;
    }

    private String promotionId;

    /**
     * @return 
     */
    public String getPromotionId() {
        return promotionId;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setPromotionId(String promotionId) {
        this.promotionId = promotionId;
    }

    private String[] crossPromotionIds;

    /**
     * @return 
     */
    public String[] getCrossPromotionIds() {
        return crossPromotionIds;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCrossPromotionIds(String[] crossPromotionIds) {
        this.crossPromotionIds = crossPromotionIds;
    }

    private String[] crossShopPromotions;

    /**
     * @return 
     */
    public String[] getCrossShopPromotions() {
        return crossShopPromotions;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setCrossShopPromotions(String[] crossShopPromotions) {
        this.crossShopPromotions = crossShopPromotions;
    }

    private Boolean isChooseFreeFreight;

    /**
     * @return 
     */
    public Boolean getIsChooseFreeFreight() {
        return isChooseFreeFreight;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setIsChooseFreeFreight(Boolean isChooseFreeFreight) {
        this.isChooseFreeFreight = isChooseFreeFreight;
    }

    private Long sumPaymentNoCarriageFromClient;

    /**
     * @return 
     */
    public Long getSumPaymentNoCarriageFromClient() {
        return sumPaymentNoCarriageFromClient;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSumPaymentNoCarriageFromClient(Long sumPaymentNoCarriageFromClient) {
        this.sumPaymentNoCarriageFromClient = sumPaymentNoCarriageFromClient;
    }

    private Long subUserId;

    /**
     * @return 
     */
    public Long getSubUserId() {
        return subUserId;
    }

    /**
     * 设置     *
     * 参数示例：<pre></pre>     
     * 此参数必填
     */
    public void setSubUserId(Long subUserId) {
        this.subUserId = subUserId;
    }

}
