package com.alibaba.trade.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaOceanOpenplatformBizTradeCommonModelOpMaxRefundFeeModel {

    private Long maxGoodsFee;

    /**
     * @return 最大可退款货品金额，单位：分
     */
    public Long getMaxGoodsFee() {
        return maxGoodsFee;
    }

    /**
     * 设置最大可退款货品金额，单位：分     *
     * 参数示例：<pre>7</pre>     
     * 此参数必填
     */
    public void setMaxGoodsFee(Long maxGoodsFee) {
        this.maxGoodsFee = maxGoodsFee;
    }

    private Long maxPostFee;

    /**
     * @return 最大可退运费，单位：分
     */
    public Long getMaxPostFee() {
        return maxPostFee;
    }

    /**
     * 设置最大可退运费，单位：分     *
     * 参数示例：<pre>2</pre>     
     * 此参数必填
     */
    public void setMaxPostFee(Long maxPostFee) {
        this.maxPostFee = maxPostFee;
    }

    private Long maxRefundFee;

    /**
     * @return 最大可退款金额，即运费+货品金额的上限值，单位：分
     */
    public Long getMaxRefundFee() {
        return maxRefundFee;
    }

    /**
     * 设置最大可退款金额，即运费+货品金额的上限值，单位：分     *
     * 参数示例：<pre>9</pre>     
     * 此参数必填
     */
    public void setMaxRefundFee(Long maxRefundFee) {
        this.maxRefundFee = maxRefundFee;
    }

    private Long maxSubstituteFetchFee;

    /**
     * @return 最大可退官方代提服务费，单位：分
     */
    public Long getMaxSubstituteFetchFee() {
        return maxSubstituteFetchFee;
    }

    /**
     * 设置最大可退官方代提服务费，单位：分     *
     * 参数示例：<pre>0</pre>     
     * 此参数必填
     */
    public void setMaxSubstituteFetchFee(Long maxSubstituteFetchFee) {
        this.maxSubstituteFetchFee = maxSubstituteFetchFee;
    }

}
