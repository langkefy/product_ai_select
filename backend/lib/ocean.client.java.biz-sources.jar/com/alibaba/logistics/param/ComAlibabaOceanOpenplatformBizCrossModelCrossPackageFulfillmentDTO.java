package com.alibaba.logistics.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizCrossModelCrossPackageFulfillmentDTO {

    private String crossMailNo;

    /**
     * @return 单号
     */
    public String getCrossMailNo() {
        return crossMailNo;
    }

    /**
     * 设置单号     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setCrossMailNo(String crossMailNo) {
        this.crossMailNo = crossMailNo;
    }

    private String orderId;

    /**
     * @return 订单id
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * 设置订单id     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    private ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTO[] crossPackageTraceDTOList;

    /**
     * @return 运踪极点list
     */
    public ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTO[] getCrossPackageTraceDTOList() {
        return crossPackageTraceDTOList;
    }

    /**
     * 设置运踪极点list     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setCrossPackageTraceDTOList(ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTO[] crossPackageTraceDTOList) {
        this.crossPackageTraceDTOList = crossPackageTraceDTOList;
    }

}
