package com.alibaba.logistics.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTO {

    private String buyerUserId;

    /**
     * @return 买家id
     */
    public String getBuyerUserId() {
        return buyerUserId;
    }

    /**
     * 设置买家id     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setBuyerUserId(String buyerUserId) {
        this.buyerUserId = buyerUserId;
    }

    private String carrierPartnerCode;

    /**
     * @return 物流公司CODE
     */
    public String getCarrierPartnerCode() {
        return carrierPartnerCode;
    }

    /**
     * 设置物流公司CODE     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setCarrierPartnerCode(String carrierPartnerCode) {
        this.carrierPartnerCode = carrierPartnerCode;
    }

    private String outTraceNodeCode;

    /**
     * @return 外部运踪Code
     */
    public String getOutTraceNodeCode() {
        return outTraceNodeCode;
    }

    /**
     * 设置外部运踪Code     *
     * 参数示例：<pre>23</pre>     
     * 此参数必填
     */
    public void setOutTraceNodeCode(String outTraceNodeCode) {
        this.outTraceNodeCode = outTraceNodeCode;
    }

    private String opCode;

    /**
     * @return 操作code，异常节点的opCode
     */
    public String getOpCode() {
        return opCode;
    }

    /**
     * 设置操作code，异常节点的opCode     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setOpCode(String opCode) {
        this.opCode = opCode;
    }

    private String nodeActionTime;

    /**
     * @return nodeActionTime
     */
    public String getNodeActionTime() {
        return nodeActionTime;
    }

    /**
     * 设置nodeActionTime     *
     * 参数示例：<pre>12</pre>     
     * 此参数必填
     */
    public void setNodeActionTime(String nodeActionTime) {
        this.nodeActionTime = nodeActionTime;
    }

    private String nodeDetail;

    /**
     * @return nodeDetail
     */
    public String getNodeDetail() {
        return nodeDetail;
    }

    /**
     * 设置nodeDetail     *
     * 参数示例：<pre>23</pre>     
     * 此参数必填
     */
    public void setNodeDetail(String nodeDetail) {
        this.nodeDetail = nodeDetail;
    }

    private String stageType;

    /**
     * @return stageType
     */
    public String getStageType() {
        return stageType;
    }

    /**
     * 设置stageType     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setStageType(String stageType) {
        this.stageType = stageType;
    }

    private ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOTraceNode traceNode;

    /**
     * @return 运踪节点
     */
    public ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOTraceNode getTraceNode() {
        return traceNode;
    }

    /**
     * 设置运踪节点     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setTraceNode(ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOTraceNode traceNode) {
        this.traceNode = traceNode;
    }

    private ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOErrorTraceInfo traceException;

    /**
     * @return 异常节点
     */
    public ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOErrorTraceInfo getTraceException() {
        return traceException;
    }

    /**
     * 设置异常节点     *
     * 参数示例：<pre>{}</pre>     
     * 此参数必填
     */
    public void setTraceException(ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOErrorTraceInfo traceException) {
        this.traceException = traceException;
    }

}
