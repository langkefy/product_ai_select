package com.alibaba.logistics.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOTraceNode {

    private String traceNodeName;

    /**
     * @return 节点名称
     */
    public String getTraceNodeName() {
        return traceNodeName;
    }

    /**
     * 设置节点名称     *
     * 参数示例：<pre>仓库</pre>     
     * 此参数必填
     */
    public void setTraceNodeName(String traceNodeName) {
        this.traceNodeName = traceNodeName;
    }

    private String traceNodeCode;

    /**
     * @return 节点
     */
    public String getTraceNodeCode() {
        return traceNodeCode;
    }

    /**
     * 设置节点     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setTraceNodeCode(String traceNodeCode) {
        this.traceNodeCode = traceNodeCode;
    }

}
