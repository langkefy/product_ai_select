package com.alibaba.logistics.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaOceanOpenplatformBizCrossModelCrossPackageTraceDTOErrorTraceInfo {

    private String exceptionCode;

    /**
     * @return 异常code
     */
    public String getExceptionCode() {
        return exceptionCode;
    }

    /**
     * 设置异常code     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setExceptionCode(String exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    private String traceNodeCode;

    /**
     * @return 异常节点
     */
    public String getTraceNodeCode() {
        return traceNodeCode;
    }

    /**
     * 设置异常节点     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setTraceNodeCode(String traceNodeCode) {
        this.traceNodeCode = traceNodeCode;
    }

    private String exceptionDesc;

    /**
     * @return 异常
     */
    public String getExceptionDesc() {
        return exceptionDesc;
    }

    /**
     * 设置异常     *
     * 参数示例：<pre>12</pre>     
     * 此参数必填
     */
    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

}
