package com.alibaba.ocean.rawsdk.example;

import com.alibaba.ocean.rawsdk.ApiExecutor;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * @author qiuwu [qiuwu.sjl@alibaba-inc.com].
 * @date Created at 2023/7/31 2:10 PM.
 */
public class RawSdkProxyExample {
    private static final int PROXY_PORT = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("{host}", PROXY_PORT));
        ApiExecutor apiExecutor = new ApiExecutor("{appKey}", "{appSecret}", proxy);
    }
}
