package com.alibaba.ai.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class OpenAgentSupplyChangeDataFeedbackParam extends AbstractAPIRequest<OpenAgentSupplyChangeDataFeedbackResult> {

    public OpenAgentSupplyChangeDataFeedbackParam() {
        super();
        oceanApiId = new APIId("com.alibaba.ai", "open.agent.supplyChangeDataFeedback", 1);
    }

    private String relationId;

    /**
     * @return 外部唯一标识
     */
    public String getRelationId() {
        return relationId;
    }

    /**
     * 设置外部唯一标识     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setRelationId(String relationId) {
        this.relationId = relationId;
    }

    private String offerId;

    /**
     * @return 商品id
     */
    public String getOfferId() {
        return offerId;
    }

    /**
     * 设置商品id     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    private String skuId;

    /**
     * @return skuId
     */
    public String getSkuId() {
        return skuId;
    }

    /**
     * 设置skuId     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    private String reason;

    /**
     * @return 原因
     */
    public String getReason() {
        return reason;
    }

    /**
     * 设置原因     *
     * 参数示例：<pre>推荐不准确</pre>     
     * 此参数必填
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    private String skuName;

    /**
     * @return skuName
     */
    public String getSkuName() {
        return skuName;
    }

    /**
     * 设置skuName     *
     * 参数示例：<pre>规格名称</pre>     
     * 此参数必填
     */
    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    private String accepted;

    /**
     * @return 是否被采纳
     */
    public String getAccepted() {
        return accepted;
    }

    /**
     * 设置是否被采纳     *
     * 参数示例：<pre>true为采纳，false为不采纳</pre>     
     * 此参数必填
     */
    public void setAccepted(String accepted) {
        this.accepted = accepted;
    }

}
