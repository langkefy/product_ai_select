package com.alibaba.ai.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class AlibabaAiInfraAgentSupplyParamSupplyMatchData {

    private String relationId;

    /**
     * @return 外部sku粒度唯一标识
     */
    public String getRelationId() {
        return relationId;
    }

    /**
     * 设置外部sku粒度唯一标识     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setRelationId(String relationId) {
        this.relationId = relationId;
    }

    private Boolean isCbuOffer;

    /**
     * @return 原供给是否为1688平台供给
     */
    public Boolean getIsCbuOffer() {
        return isCbuOffer;
    }

    /**
     * 设置原供给是否为1688平台供给     *
     * 参数示例：<pre>true or false</pre>     
     * 此参数必填
     */
    public void setIsCbuOffer(Boolean isCbuOffer) {
        this.isCbuOffer = isCbuOffer;
    }

    private String supplyPlatform;

    /**
     * @return 原供给来源平台
     */
    public String getSupplyPlatform() {
        return supplyPlatform;
    }

    /**
     * 设置原供给来源平台     *
     * 参数示例：<pre>1688/pdd</pre>     
     * 此参数必填
     */
    public void setSupplyPlatform(String supplyPlatform) {
        this.supplyPlatform = supplyPlatform;
    }

    private String offerId;

    /**
     * @return 原供给商品id
     */
    public String getOfferId() {
        return offerId;
    }

    /**
     * 设置原供给商品id     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    private String title;

    /**
     * @return 原供给商品标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置原供给商品标题     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setTitle(String title) {
        this.title = title;
    }

    private String skuId;

    /**
     * @return 原供给商品skuId
     */
    public String getSkuId() {
        return skuId;
    }

    /**
     * 设置原供给商品skuId     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    private String skuName;

    /**
     * @return 原供给商品sku名称
     */
    public String getSkuName() {
        return skuName;
    }

    /**
     * 设置原供给商品sku名称     *
     * 参数示例：<pre>12345678</pre>     
     * 此参数必填
     */
    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    private String picture;

    /**
     * @return 原供给商品主图
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 设置原供给商品主图     *
     * 参数示例：<pre>url</pre>     
     * 此参数必填
     */
    public void setPicture(String picture) {
        this.picture = picture;
    }

    private String skuPicture;

    /**
     * @return 原供给商品sku图
     */
    public String getSkuPicture() {
        return skuPicture;
    }

    /**
     * 设置原供给商品sku图     *
     * 参数示例：<pre>url</pre>     
     * 此参数必填
     */
    public void setSkuPicture(String skuPicture) {
        this.skuPicture = skuPicture;
    }

    private String cpv;

    /**
     * @return 原供给商品核心属性
     */
    public String getCpv() {
        return cpv;
    }

    /**
     * 设置原供给商品核心属性     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setCpv(String cpv) {
        this.cpv = cpv;
    }

    private String skuCpv;

    /**
     * @return 原供给商品sku核心属性
     */
    public String getSkuCpv() {
        return skuCpv;
    }

    /**
     * 设置原供给商品sku核心属性     *
     * 参数示例：<pre>123</pre>     
     * 此参数必填
     */
    public void setSkuCpv(String skuCpv) {
        this.skuCpv = skuCpv;
    }

    private Double price;

    /**
     * @return 原供给商品sku进货价
     */
    public Double getPrice() {
        return price;
    }

    /**
     * 设置原供给商品sku进货价     *
     * 参数示例：<pre>12.3456</pre>     
     * 此参数必填
     */
    public void setPrice(Double price) {
        this.price = price;
    }

    private Integer count;

    /**
     * @return 原供给商品sku采购量
     */
    public Integer getCount() {
        return count;
    }

    /**
     * 设置原供给商品sku采购量     *
     * 参数示例：<pre>1000</pre>     
     * 此参数必填
     */
    public void setCount(Integer count) {
        this.count = count;
    }

    private String supplyAddress;

    /**
     * @return 原供给商品发货地
     */
    public String getSupplyAddress() {
        return supplyAddress;
    }

    /**
     * 设置原供给商品发货地     *
     * 参数示例：<pre>浙江省杭州市西湖区</pre>     
     * 此参数必填
     */
    public void setSupplyAddress(String supplyAddress) {
        this.supplyAddress = supplyAddress;
    }

    private Boolean isFreeShipping;

    /**
     * @return 原供给商品是否包邮
     */
    public Boolean getIsFreeShipping() {
        return isFreeShipping;
    }

    /**
     * 设置原供给商品是否包邮     *
     * 参数示例：<pre>true or false</pre>     
     * 此参数必填
     */
    public void setIsFreeShipping(Boolean isFreeShipping) {
        this.isFreeShipping = isFreeShipping;
    }

    private String deliveryTime;

    /**
     * @return 原供给商品发货时效
     */
    public String getDeliveryTime() {
        return deliveryTime;
    }

    /**
     * 设置原供给商品发货时效     *
     * 参数示例：<pre>ssbxhfh(48小时发货)</pre>     
     * 此参数必填
     */
    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

}
