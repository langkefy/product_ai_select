package com.alibaba.ai.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class OpenAgentSupplyChangeParam extends AbstractAPIRequest<OpenAgentSupplyChangeResult> {

    public OpenAgentSupplyChangeParam() {
        super();
        oceanApiId = new APIId("com.alibaba.ai", "open.agent.supplyChange", 1);
    }

    private String batchId;

    /**
     * @return 批次id
     */
    public String getBatchId() {
        return batchId;
    }

    /**
     * 设置批次id     *
     * 参数示例：<pre>123456</pre>     
     * 此参数必填
     */
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    private AlibabaAiInfraAgentSupplyParamSupplyMatchData[] supplyChangeDatas;

    /**
     * @return 具体入参信息
     */
    public AlibabaAiInfraAgentSupplyParamSupplyMatchData[] getSupplyChangeDatas() {
        return supplyChangeDatas;
    }

    /**
     * 设置具体入参信息     *
     * 参数示例：<pre>123456</pre>     
     * 此参数必填
     */
    public void setSupplyChangeDatas(AlibabaAiInfraAgentSupplyParamSupplyMatchData[] supplyChangeDatas) {
        this.supplyChangeDatas = supplyChangeDatas;
    }

}
