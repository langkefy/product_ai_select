package com.alibaba.ai.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class OpenAgentSupplyChangeResult {

    private Boolean success;

    /**
     * @return 是否调用成功
     */
    public Boolean getSuccess() {
        return success;
    }

    /**
     * 设置是否调用成功     *
          
     * 此参数必填
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }

    private String batchId;

    /**
     * @return 批次id
     */
    public String getBatchId() {
        return batchId;
    }

    /**
     * 设置批次id     *
          
     * 此参数必填
     */
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    private ComAlibabaAiInfraAgentSupplyModelSupplyChangeAgentModel[] modelList;

    /**
     * @return 数据list
     */
    public ComAlibabaAiInfraAgentSupplyModelSupplyChangeAgentModel[] getModelList() {
        return modelList;
    }

    /**
     * 设置数据list     *
          
     * 此参数必填
     */
    public void setModelList(ComAlibabaAiInfraAgentSupplyModelSupplyChangeAgentModel[] modelList) {
        this.modelList = modelList;
    }

    private String errorMessage;

    /**
     * @return 错误信息
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * 设置错误信息     *
          
     * 此参数必填
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
