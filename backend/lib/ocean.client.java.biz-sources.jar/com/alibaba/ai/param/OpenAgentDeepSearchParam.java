package com.alibaba.ai.param;

import com.alibaba.ocean.rawsdk.client.APIId;
import com.alibaba.ocean.rawsdk.common.AbstractAPIRequest;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class OpenAgentDeepSearchParam extends AbstractAPIRequest<OpenAgentDeepSearchResult> {

    public OpenAgentDeepSearchParam() {
        super();
        oceanApiId = new APIId("com.alibaba.ai", "open.agent.deepSearch", 1);
    }

}
