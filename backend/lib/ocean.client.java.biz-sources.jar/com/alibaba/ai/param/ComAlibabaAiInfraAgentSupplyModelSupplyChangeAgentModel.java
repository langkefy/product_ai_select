package com.alibaba.ai.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ComAlibabaAiInfraAgentSupplyModelSupplyChangeAgentModel {

    private String status;

    /**
     * @return 状态信息
     */
    public String getStatus() {
        return status;
    }

    /**
     * 设置状态信息     *
     * 参数示例：<pre>processing</pre>     
     * 此参数必填
     */
    public void setStatus(String status) {
        this.status = status;
    }

    private String instanceId;

    /**
     * @return traceId
     */
    public String getInstanceId() {
        return instanceId;
    }

    /**
     * 设置traceId     *
     * 参数示例：<pre>123456</pre>     
     * 此参数必填
     */
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    private String relationId;

    /**
     * @return 外部唯一标识
     */
    public String getRelationId() {
        return relationId;
    }

    /**
     * 设置外部唯一标识     *
     * 参数示例：<pre>123456</pre>     
     * 此参数必填
     */
    public void setRelationId(String relationId) {
        this.relationId = relationId;
    }

    private String errorInfo;

    /**
     * @return 错误信息
     */
    public String getErrorInfo() {
        return errorInfo;
    }

    /**
     * 设置错误信息     *
     * 参数示例：<pre>超时</pre>     
     * 此参数必填
     */
    public void setErrorInfo(String errorInfo) {
        this.errorInfo = errorInfo;
    }

}
